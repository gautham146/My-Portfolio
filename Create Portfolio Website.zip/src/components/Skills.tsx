import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

export default function Skills() {
  // const titleRef = useRef(null); // Keeping ref available for typing animation
  
  const skills = [
    { name: "React", level: 90 },
    { name: "JavaScript", level: 95 },
    { name: "Python", level: 85 },
    { name: "Node.js", level: 80 },
    { name: "TypeScript", level: 75 },
    { name: "CSS/Tailwind", level: 90 },
    { name: "MongoDB", level: 70 },
    { name: "Git", level: 85 },
    { name: "AWS", level: 65 },
    { name: "Docker", level: 60 }
  ];

  // Typing animation function (kept for future use)
  // useEffect(() => {
  //   gsap.to(titleRef.current, {
  //     text: "Skills & Expertise",
  //     duration: 2,
  //     ease: "none",
  //     scrollTrigger: {
  //       trigger: titleRef.current,
  //       start: "top 80%",
  //       toggleActions: "play none none reverse"
  //     }
  //   });
  // }, []);

  return (
    <section className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.h2 
          // ref={titleRef} // Keeping ref for potential typing animation
          className="text-4xl md:text-5xl mb-16 text-center font-semibold"
          style={{ fontFamily: "'Poppins', sans-serif" }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Skills & Expertise
        </motion.h2>
        
        <div className="space-y-6">
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              className="space-y-2"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="flex justify-between items-center">
                <span className="font-medium text-lg">{skill.name}</span>
                <span className="text-stone-600">{skill.level}%</span>
              </div>
              <div className="w-full bg-stone-200 rounded-full h-3">
                <motion.div
                  className="bg-gradient-to-r from-stone-800 to-stone-600 h-3 rounded-full"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                  viewport={{ once: true }}
                />
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          viewport={{ once: true }}
        >
          {/* <TypewriterText  // Keeping component for potential future use
            text="I'm always eager to learn new technologies and expand my skill set. Currently exploring machine learning, cloud architecture, and mobile development."
            delay={3}
            className="text-lg text-stone-600 max-w-3xl mx-auto leading-relaxed"
          /> */}
          <p className="text-lg text-stone-600 max-w-3xl mx-auto leading-relaxed">
            I'm always eager to learn new technologies and expand my skill set. Currently exploring machine learning, cloud architecture, and mobile development.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// Keeping TypewriterText component for potential future use
// function TypewriterText({ text, delay, className }) {
//   const textRef = useRef(null);

//   useEffect(() => {
//     gsap.to(textRef.current, {
//       text: text,
//       duration: text.length * 0.03,
//       ease: "none",
//       scrollTrigger: {
//         trigger: textRef.current,
//         start: "top 85%",
//         toggleActions: "play none none reverse"
//       },
//       delay: delay
//     });
//   }, [text, delay]);

//   return <p ref={textRef} className={className} />;
// }