import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';

interface ElegantIntroProps {
  onComplete: () => void;
}

const ElegantIntro: React.FC<ElegantIntroProps> = ({ onComplete }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const nameRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    const name = nameRef.current;
    const line = lineRef.current;

    if (!container || !name || !line) return;

    const tl = gsap.timeline();

    // Initial state
    gsap.set([name, line], { opacity: 0, y: 30 });

    tl
      // Fade in name
      .to(name, {
        opacity: 1,
        y: 0,
        duration: 1.5,
        ease: "power3.out"
      })
      // Show decorative line
      .to(line, {
        opacity: 1,
        scaleX: 1,
        duration: 1,
        ease: "power2.out"
      }, "-=0.5")
      // Hold for a moment
      .to({}, { duration: 1.5 })
      // Fade out everything
      .to([name, line], {
        opacity: 0,
        y: -20,
        duration: 1,
        ease: "power2.in"
      })
      // Fade out container
      .to(container, {
        opacity: 0,
        duration: 0.8,
        ease: "power2.in",
        onComplete: () => {
          setTimeout(onComplete, 300);
        }
      });

  }, [onComplete]);

  return (
    <motion.div
      ref={containerRef}
      className="fixed inset-0 bg-white flex items-center justify-center z-50"
      initial={{ opacity: 1 }}
    >
      <div className="text-center">
        <div ref={nameRef} className="mb-8">
          <h1 className="text-5xl md:text-7xl font-light tracking-wider text-gray-900 mb-4">
            Gautham Girish
          </h1>
          <p className="text-lg md:text-xl text-gray-600 font-light tracking-wide">
            Creative Developer
          </p>
        </div>
        
        <div
          ref={lineRef}
          className="w-24 h-px bg-gray-400 mx-auto"
          style={{ transformOrigin: 'left', transform: 'scaleX(0)' }}
        />
      </div>

      {/* Subtle background elements */}
      <div className="absolute top-20 left-20 w-32 h-px bg-gray-200 opacity-30" />
      <div className="absolute bottom-20 right-20 w-24 h-px bg-gray-200 opacity-30" />
      <div className="absolute top-1/2 left-10 w-px h-16 bg-gray-200 opacity-30" />
      <div className="absolute top-1/2 right-10 w-px h-12 bg-gray-200 opacity-30" />
    </motion.div>
  );
};

export default ElegantIntro;