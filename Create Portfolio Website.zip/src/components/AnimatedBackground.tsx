import React from 'react';
import { motion } from 'motion/react';

const AnimatedBackground = () => {
  // Generate random positions and delays for floating elements
  const floatingElements = Array.from({ length: 6 }, (_, i) => ({
    id: i,
    size: Math.random() * 120 + 80, // 80-200px
    x: Math.random() * 100, // 0-100%
    y: Math.random() * 100, // 0-100%
    delay: Math.random() * 4, // 0-4s delay
    duration: Math.random() * 10 + 15, // 15-25s duration
  }));

  const gridLines = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    position: (i + 1) * 12.5, // Every 12.5% across the screen
    delay: i * 0.2,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-30">
      {/* Subtle grid lines */}
      <div className="absolute inset-0">
        {gridLines.map((line) => (
          <motion.div
            key={`v-${line.id}`}
            className="absolute h-full w-px bg-gradient-to-b from-transparent via-stone-300 to-transparent"
            style={{ left: `${line.position}%` }}
            initial={{ opacity: 0, scaleY: 0 }}
            animate={{ opacity: 0.4, scaleY: 1 }}
            transition={{
              duration: 2,
              delay: line.delay,
              ease: "easeOut"
            }}
          />
        ))}
        {gridLines.slice(0, 6).map((line) => (
          <motion.div
            key={`h-${line.id}`}
            className="absolute w-full h-px bg-gradient-to-r from-transparent via-stone-300 to-transparent"
            style={{ top: `${line.position}%` }}
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 0.4, scaleX: 1 }}
            transition={{
              duration: 2,
              delay: line.delay + 0.5,
              ease: "easeOut"
            }}
          />
        ))}
      </div>

      {/* Floating geometric elements */}
      {floatingElements.map((element) => (
        <motion.div
          key={element.id}
          className="absolute"
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            width: element.size,
            height: element.size,
          }}
          initial={{ 
            opacity: 0, 
            scale: 0,
            rotate: 0 
          }}
          animate={{ 
            opacity: [0, 0.6, 0.3, 0.6, 0],
            scale: [0, 1, 1.2, 1, 0],
            rotate: 360,
            x: [0, 50, -30, 20, 0],
            y: [0, -30, 40, -20, 0]
          }}
          transition={{
            duration: element.duration,
            delay: element.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {element.id % 3 === 0 && (
            // Circle
            <div className="w-full h-full rounded-full border border-stone-400/30 bg-stone-200/20" />
          )}
          {element.id % 3 === 1 && (
            // Square
            <div className="w-full h-full border border-stone-400/30 bg-stone-200/20 rotate-12" />
          )}
          {element.id % 3 === 2 && (
            // Triangle
            <div 
              className="w-full h-full bg-stone-200/20"
              style={{
                clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
                border: '1px solid rgba(120, 113, 108, 0.3)'
              }}
            />
          )}
        </motion.div>
      ))}

      {/* Subtle radial gradient overlay */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent via-stone-50/30 to-stone-100/50" />
      
      {/* Corner accents */}
      <motion.div
        className="absolute top-0 right-0 w-96 h-96 opacity-20"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 0.2, scale: 1 }}
        transition={{ duration: 3, delay: 1 }}
      >
        <div className="w-full h-full bg-gradient-to-bl from-stone-300/40 to-transparent rounded-full blur-3xl" />
      </motion.div>
      
      <motion.div
        className="absolute bottom-0 left-0 w-80 h-80 opacity-20"
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 0.2, scale: 1 }}
        transition={{ duration: 3, delay: 1.5 }}
      >
        <div className="w-full h-full bg-gradient-to-tr from-stone-300/40 to-transparent rounded-full blur-3xl" />
      </motion.div>
    </div>
  );
};

export default AnimatedBackground;