import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight, Users, Award, BookOpen, PenTool, Calendar, Target, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

gsap.registerPlugin(ScrollTrigger);

const CarouselExtracurriculars = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  const activities = [
    {
      title: "Computer Science Club",
      role: "Vice President",
      description: "Leading a team of 50+ students in organizing coding competitions, workshops, and tech talks.",
      fullDescription: "As Vice President of the Computer Science Club, I've spearheaded the transformation of our organization into one of the most active tech communities on campus. My leadership has involved strategic planning, team coordination, and creating an inclusive environment where students from all backgrounds can explore technology.",
      period: "2023 - Present",
      icon: Users,
      metrics: ["50+ Members", "15+ Colleges", "12 Events"],
      achievements: [
        "Increased membership by 300% in one year",
        "Organized the largest campus hackathon with 200+ participants",
        "Established partnerships with 5 major tech companies"
      ],
      bgColor: "bg-blue-50",
      accentColor: "bg-blue-500",
      textColor: "text-blue-600",
      image: "https://images.unsplash.com/photo-1753613648137-602c669cbe07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHNjaWVuY2UlMjBjb2RpbmclMjBzdHVkZW50c3xlbnwxfHx8fDE3NTkwMDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Debate Society",
      role: "Active Member",
      description: "Participated in inter-college debate competitions, developing critical thinking and public speaking skills.",
      fullDescription: "My involvement in the Debate Society has been instrumental in developing my communication and analytical skills. Through rigorous training sessions and competitive debates, I've learned to articulate complex ideas clearly, think critically under pressure, and defend positions with well-researched arguments.",
      period: "2022 - Present",
      icon: Award,
      metrics: ["8 Competitions", "3 Awards", "2 Years"],
      achievements: [
        "Won 3 inter-college debate competitions",
        "Ranked in top 10 at national debate championship",
        "Trained 15+ new members in debate techniques"
      ],
      bgColor: "bg-purple-50",
      accentColor: "bg-purple-500",
      textColor: "text-purple-600",
      image: "https://images.unsplash.com/photo-1709377418835-304afc0e064a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxyZXNlYXJjaCUyMGxhYiUyMHRlY2hub2xvZ3klMjBpbm5vdmF0aW9ufGVufDF8fHx8MTc1OTAxMDIxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Community Service Initiative",
      role: "Volunteer Coordinator",
      description: "Organized digital literacy programs for underprivileged communities, teaching basic computer skills.",
      fullDescription: "Coordinating community service initiatives has been one of my most rewarding experiences. I've designed and implemented comprehensive digital literacy programs that bridge the technology gap in underserved communities. My role involved curriculum development, volunteer training, resource management, and direct teaching.",
      period: "2022 - 2024",
      icon: BookOpen,
      metrics: ["100+ Students", "5 Programs", "24 Months"],
      achievements: [
        "Established 3 permanent computer labs in community centers",
        "Trained 25 volunteer instructors",
        "Achieved 95% course completion rate"
      ],
      bgColor: "bg-green-50",
      accentColor: "bg-green-500",
      textColor: "text-green-600",
      image: "https://images.unsplash.com/photo-1743793174491-bcbdf1882ad5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBzZXJ2aWNlJTIwdGVhY2hpbmclMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1OTAwNjA0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "University Tech Magazine",
      role: "Contributing Writer",
      description: "Writing articles about emerging technologies, startup culture, and the intersection of tech and society.",
      fullDescription: "Contributing to the University Tech Magazine has allowed me to explore the intersection of technology and society through written expression. My articles cover emerging technologies, startup ecosystems, and the societal implications of digital transformation.",
      period: "2023 - Present",
      icon: PenTool,
      metrics: ["15 Articles", "10K+ Readers", "Monthly"],
      achievements: [
        "Published cover story on AI ethics reaching 50K+ readers",
        "Interviewed 20+ industry leaders and startup founders",
        "Created multimedia content strategy increasing engagement by 200%"
      ],
      bgColor: "bg-orange-50",
      accentColor: "bg-orange-500",
      textColor: "text-orange-600",
      image: "https://images.unsplash.com/photo-1663025292954-dd09983bd945?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3cml0aW5nJTIwbWFnYXppbmUlMjBqb3VybmFsaXNtJTIwdGVjaHxlbnwxfHx8fDE3NTkwMDYwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    ScrollTrigger.create({
      trigger: section,
      start: "top 80%",
      onEnter: () => {
        gsap.fromTo('.carousel-container', 
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 1, ease: "power2.out" }
        );
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % activities.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + activities.length) % activities.length);
  };

  const getVisibleCards = () => {
    const cards = [];
    for (let i = 0; i < 3; i++) {
      const index = (currentIndex + i) % activities.length;
      cards.push({ ...activities[index], originalIndex: index });
    }
    return cards;
  };

  return (
    <section id="extracurriculars" ref={sectionRef} className="py-32 relative bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Leadership & Impact
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto font-light leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Hover over any card to explore my leadership journey and community impact in detail.
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* Carousel Container */}
        <div className="carousel-container relative">
          
          {/* Navigation arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white shadow-lg rounded-full flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-110"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
          
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white shadow-lg rounded-full flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-110"
          >
            <ChevronRight className="w-6 h-6 text-gray-600" />
          </button>

          {/* Cards Container */}
          <div className="mx-16">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {getVisibleCards().map((activity, index) => (
                <motion.div
                  key={`${activity.originalIndex}-${currentIndex}`}
                  className="relative"
                  onMouseEnter={() => setHoveredCard(activity.originalIndex)}
                  onMouseLeave={() => setHoveredCard(null)}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  
                  {/* Base Card */}
                  <div className={`${activity.bgColor} rounded-2xl p-8 h-80 transition-all duration-500 cursor-pointer group relative overflow-hidden ${
                    hoveredCard === activity.originalIndex ? 'transform scale-105 shadow-2xl' : 'hover:shadow-lg'
                  }`}>
                    
                    {/* Card Header */}
                    <div className="flex items-start justify-between mb-6">
                      <div className={`w-12 h-12 ${activity.accentColor} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                        <activity.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500 mb-1">
                          {activity.period}
                        </div>
                        <div className={`text-xs ${activity.textColor} font-medium uppercase tracking-wider`}>
                          {activity.role}
                        </div>
                      </div>
                    </div>

                    {/* Card Content */}
                    <h3 className="text-xl font-semibold text-gray-900 mb-4 group-hover:text-gray-800 transition-colors duration-300" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {activity.title}
                    </h3>
                    
                    <p className="text-gray-600 text-sm leading-relaxed font-light mb-6">
                      {activity.description}
                    </p>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-4">
                      {activity.metrics.map((metric, metricIndex) => (
                        <div key={metricIndex} className="text-center">
                          <div className="text-lg font-semibold text-gray-900">
                            {metric.split(' ')[0]}
                          </div>
                          <div className="text-xs text-gray-500 uppercase tracking-wider">
                            {metric.split(' ').slice(1).join(' ')}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Hover indicator */}
                    <div className={`absolute bottom-0 left-0 w-full h-1 ${activity.accentColor} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left`}></div>
                  </div>

                  {/* Expanded Hover Card */}
                  <AnimatePresence>
                    {hoveredCard === activity.originalIndex && (
                      <motion.div
                        className="absolute inset-0 z-20"
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        transition={{ duration: 0.3, ease: "easeOut" }}
                      >
                        <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden h-full">
                          
                          {/* Image Header */}
                          <div className="relative h-48 overflow-hidden">
                            <ImageWithFallback
                              src={activity.image}
                              alt={activity.title}
                              className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                            
                            {/* Badge */}
                            <div className="absolute top-4 left-4">
                              <div className={`${activity.bgColor} backdrop-blur-md px-3 py-1 rounded-full border border-white/20`}>
                                <span className={`text-xs font-medium ${activity.textColor}`}>{activity.role}</span>
                              </div>
                            </div>
                          </div>

                          {/* Content */}
                          <div className="p-6">
                            
                            {/* Title and period */}
                            <div className="flex items-start justify-between mb-4">
                              <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-1" style={{ fontFamily: "'Playfair Display', serif" }}>
                                  {activity.title}
                                </h3>
                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                  <Calendar className="w-3 h-3" />
                                  <span>{activity.period}</span>
                                </div>
                              </div>
                            </div>

                            {/* Full Description */}
                            <p className="text-sm text-gray-600 leading-relaxed font-light mb-4 line-clamp-3">
                              {activity.fullDescription}
                            </p>

                            {/* Key Achievements */}
                            <div className="space-y-3">
                              <h4 className="text-xs font-semibold text-gray-800 uppercase tracking-wide flex items-center gap-1">
                                <Target className="w-3 h-3" />
                                Key Achievements
                              </h4>
                              <div className="space-y-2">
                                {activity.achievements.slice(0, 2).map((achievement, achIndex) => (
                                  <div key={achIndex} className="flex items-start gap-2">
                                    <div className={`w-1.5 h-1.5 rounded-full ${activity.accentColor} mt-2 flex-shrink-0`}></div>
                                    <span className="text-xs text-gray-700 leading-relaxed">
                                      {achievement}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Pagination dots */}
          <div className="flex justify-center gap-2 mt-12">
            {activities.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  currentIndex === index ? 'bg-gray-600 w-8' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Philosophy section */}
        <motion.div
          className="mt-24 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="max-w-3xl mx-auto">
            <p className="text-xl text-gray-600 font-light leading-relaxed italic">
              "Leadership isn't about being in charge. It's about taking care of those in your charge 
              and creating opportunities for others to grow."
            </p>
            <div className="w-12 h-px bg-gray-400 mx-auto mt-8" />
          </div>
        </motion.div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-32 left-16 w-16 h-px bg-gray-200 opacity-40" />
      <div className="absolute bottom-24 right-16 w-px h-20 bg-gray-200 opacity-40" />
    </section>
  );
};

export default CarouselExtracurriculars;