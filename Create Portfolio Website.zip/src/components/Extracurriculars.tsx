import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Extracurriculars() {
  const titleRef = useRef(null);
  const activities = [
    {
      title: "Computer Science Club",
      role: "Vice President",
      description: "Leading a team of 50+ students in organizing coding competitions, workshops, and tech talks. Coordinated hackathons that attracted participants from 15+ colleges.",
      period: "2023 - Present"
    },
    {
      title: "Debate Society",
      role: "Active Member",
      description: "Participated in inter-college debate competitions, developing critical thinking and public speaking skills while exploring contemporary issues.",
      period: "2022 - Present"
    },
    {
      title: "Community Service Initiative",
      role: "Volunteer Coordinator",
      description: "Organized digital literacy programs for underprivileged communities, teaching basic computer skills to 100+ individuals.",
      period: "2022 - 2024"
    },
    {
      title: "University Tech Magazine",
      role: "Contributing Writer",
      description: "Writing articles about emerging technologies, startup culture, and the intersection of tech and society for the monthly publication.",
      period: "2023 - Present"
    }
  ];

  // useEffect(() => {
  //   gsap.to(titleRef.current, {
  //     text: "Extracurricular Activities",
  //     duration: 2,
  //     ease: "none",
  //     scrollTrigger: {
  //       trigger: titleRef.current,
  //       start: "top 80%",
  //       toggleActions: "play none none reverse"
  //     }
  //   });
  // }, []);

  return (
    <section className="py-20 px-6 bg-stone-100">
      <div className="max-w-5xl mx-auto">
        <motion.h2 
          ref={titleRef}
          className="text-5xl md:text-6xl mb-16 text-center"
          style={{ fontFamily: "'Dancing Script', cursive", fontWeight: "600" }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        />
        
        <div className="space-y-8">
          {activities.map((activity, index) => (
            <motion.div
              key={index}
              className="bg-stone-50 p-8 rounded-lg shadow-sm border border-stone-200"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -5, shadow: "0 10px 25px rgba(0,0,0,0.1)" }}
            >
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl mb-2" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: "500" }}>
                    {activity.title}
                  </h3>
                  <p className="text-lg text-stone-600 mb-3">{activity.role}</p>
                </div>
                <span className="text-sm text-stone-500 bg-stone-200 px-3 py-1 rounded-full whitespace-nowrap">
                  {activity.period}
                </span>
              </div>
              <TypewriterText 
                text={activity.description}
                delay={2 + index * 0.5}
                className="text-lg text-stone-700 leading-relaxed"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TypewriterText({ text, delay, className }) {
  const textRef = useRef(null);

  useEffect(() => {
    gsap.to(textRef.current, {
      text: text,
      duration: text.length * 0.03,
      ease: "none",
      scrollTrigger: {
        trigger: textRef.current,
        start: "top 85%",
        toggleActions: "play none none reverse"
      },
      delay: delay
    });
  }, [text, delay]);

  return <p ref={textRef} className={className} />;
}