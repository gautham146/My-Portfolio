import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const AdvancedAbout = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const text = textRef.current;
    const image = imageRef.current;
    
    if (!section || !text || !image) return;

    // Text reveal animation
    ScrollTrigger.create({
      trigger: section,
      start: "top 80%",
      end: "top 20%",
      scrub: 1,
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.to(text, {
          clipPath: `inset(0 ${100 - progress * 100}% 0 0)`,
          duration: 0.3
        });
      }
    });

    // Image parallax
    ScrollTrigger.create({
      trigger: image,
      start: "top bottom",
      end: "bottom top",
      scrub: 1,
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.to(image, {
          y: progress * 100,
          scale: 1 + progress * 0.1,
          duration: 0.3
        });
      }
    });

    // Cards stagger animation
    cardsRef.current.forEach((card, index) => {
      if (!card) return;
      
      ScrollTrigger.create({
        trigger: card,
        start: "top 85%",
        onEnter: () => {
          gsap.fromTo(card, 
            { 
              y: 100, 
              opacity: 0, 
              rotationX: -30 
            },
            {
              y: 0,
              opacity: 1,
              rotationX: 0,
              duration: 1,
              delay: index * 0.2,
              ease: "power3.out"
            }
          );
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const interests = [
    {
      title: "Creative Coding",
      description: "Exploring the intersection of art and technology through generative design and interactive experiences.",
      icon: "🎨",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      title: "UI/UX Design",
      description: "Crafting intuitive and beautiful user interfaces that prioritize user experience and accessibility.",
      icon: "✨",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      title: "Music Production",
      description: "Creating electronic music and sound design, exploring the rhythm of creativity beyond visual mediums.",
      icon: "🎵",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      title: "Photography",
      description: "Capturing moments and perspectives that tell stories, with a focus on urban architecture and landscapes.",
      icon: "📸",
      gradient: "from-orange-500 to-red-500"
    }
  ];

  return (
    <section id="about" ref={sectionRef} className="min-h-screen py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-20">
          <motion.h2
            className="text-6xl md:text-7xl font-bold text-gradient mb-6"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            About Me
          </motion.h2>
          <motion.div
            className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-32">
          {/* Text content */}
          <div ref={textRef} className="space-y-8">
            <div className="relative">
              <h3 className="text-4xl font-bold mb-6 text-gradient-warm">
                Passionate Creator
              </h3>
              <p className="text-xl text-gray-600 leading-relaxed mb-6">
                I'm a creative developer who thrives at the intersection of design and technology. 
                With a background in computer science and a passion for visual storytelling, 
                I create digital experiences that are both functional and beautiful.
              </p>
              <p className="text-lg text-gray-500 leading-relaxed">
                When I'm not coding, you'll find me exploring new creative mediums, 
                from music production to photography, always seeking inspiration 
                for my next project.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-gradient">3+</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gradient-warm">25+</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Projects Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-gradient-cool">∞</div>
                <div className="text-sm text-gray-500 uppercase tracking-wider">Ideas Generated</div>
              </div>
            </div>
          </div>

          {/* Image/Visual element */}
          <div ref={imageRef} className="relative">
            <div className="relative w-full h-96 rounded-3xl overflow-hidden glass-effect">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-8xl opacity-30">👨‍💻</div>
              </div>
              {/* Floating elements around image */}
              {Array.from({ length: 6 }, (_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-4 h-4 rounded-full"
                  style={{
                    background: `linear-gradient(135deg, ${
                      ['#667eea', '#f093fb', '#4facfe', '#f5576c', '#00f2fe', '#764ba2'][i]
                    }, transparent)`,
                    left: `${Math.random() * 80 + 10}%`,
                    top: `${Math.random() * 80 + 10}%`,
                  }}
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 2 + i,
                    repeat: Infinity,
                    delay: i * 0.5,
                  }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Interests grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {interests.map((interest, index) => (
            <motion.div
              key={interest.title}
              ref={(el) => el && (cardsRef.current[index] = el)}
              className="group relative p-8 rounded-2xl glass-effect hover:scale-105 transition-all duration-300 perspective-1000"
              whileHover={{ y: -10 }}
            >
              <div className="text-center space-y-4">
                <div className="text-4xl mb-4">{interest.icon}</div>
                <h4 className="text-xl font-bold text-gray-800 mb-3">
                  {interest.title}
                </h4>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {interest.description}
                </p>
              </div>
              
              {/* Hover gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${interest.gradient} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-300`} />
              
              {/* Border gradient */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${interest.gradient} opacity-0 group-hover:opacity-20 blur-sm scale-105 transition-all duration-300`} />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Background elements */}
      <div className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-full blur-xl animate-float" />
      <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-br from-blue-400/20 to-cyan-400/20 rounded-full blur-xl animate-float" style={{ animationDelay: '2s' }} />
    </section>
  );
};

export default AdvancedAbout;