import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';

const MinimalistBackground = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Subtle floating animation for grid lines
    const gridLines = container.querySelectorAll('.grid-line');
    gridLines.forEach((line, index) => {
      gsap.to(line, {
        opacity: 0.1 + Math.random() * 0.05,
        duration: 4 + Math.random() * 2,
        repeat: -1,
        yoyo: true,
        delay: index * 0.5,
        ease: "sine.inOut"
      });
    });

    // Gentle movement for accent dots
    const dots = container.querySelectorAll('.accent-dot');
    dots.forEach((dot, index) => {
      gsap.to(dot, {
        y: "random(-10, 10)",
        x: "random(-5, 5)",
        duration: 8 + Math.random() * 4,
        repeat: -1,
        yoyo: true,
        delay: index * 1.5,
        ease: "sine.inOut"
      });
    });
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Subtle mesh gradient */}
      <div className="absolute inset-0 bg-gradient-mesh opacity-40" />
      
      {/* Minimal grid pattern */}
      <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="minimal-grid" width="80" height="80" patternUnits="userSpaceOnUse">
            <path 
              className="grid-line"
              d="M 80 0 L 0 0 0 80" 
              fill="none" 
              stroke="rgba(107, 114, 128, 0.1)" 
              strokeWidth="1"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#minimal-grid)" />
        
        {/* Subtle accent lines */}
        <motion.line
          x1="0"
          y1="20%"
          x2="100%"
          y2="20%"
          stroke="rgba(75, 85, 99, 0.08)"
          strokeWidth="1"
          className="grid-line"
        />
        <motion.line
          x1="0"
          y1="80%"
          x2="100%"
          y2="80%"
          stroke="rgba(75, 85, 99, 0.08)"
          strokeWidth="1"
          className="grid-line"
        />
      </svg>

      {/* Elegant accent dots */}
      {Array.from({ length: 8 }, (_, i) => (
        <div
          key={i}
          className="accent-dot absolute w-1 h-1 bg-gray-400 rounded-full opacity-20"
          style={{
            left: `${15 + (i % 4) * 20}%`,
            top: `${20 + Math.floor(i / 4) * 60}%`,
          }}
        />
      ))}

      {/* Soft gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent" />
      
      {/* Paper texture simulation */}
      <div 
        className="absolute inset-0 opacity-[0.02] mix-blend-multiply"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='1' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  );
};

export default MinimalistBackground;