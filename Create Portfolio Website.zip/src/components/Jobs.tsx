import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Jobs() {
  const titleRef = useRef(null);
  
  const experiences = [
    {
      company: "TechStart Solutions",
      position: "Frontend Developer Intern",
      description: "Developed responsive web applications using React and TypeScript. Collaborated with design teams to implement pixel-perfect UI components and improved application performance by 40%.",
      period: "Jun 2024 - Aug 2024",
      achievements: ["Built 5+ reusable React components", "Reduced bundle size by 25%", "Implemented dark mode feature"]
    },
    {
      company: "Digital Innovation Lab",
      position: "Research Assistant",
      description: "Conducted research on human-computer interaction and accessibility in web applications. Contributed to academic papers and presented findings at student conferences.",
      period: "Jan 2024 - May 2024",
      achievements: ["Co-authored 2 research papers", "Developed accessibility testing framework", "Presented at 3 conferences"]
    },
    {
      company: "Local Community Center",
      position: "Programming Instructor",
      description: "Taught basic programming concepts to high school students and adults. Designed curriculum for beginner-friendly coding workshops covering HTML, CSS, and JavaScript fundamentals.",
      period: "Sep 2023 - Dec 2023",
      achievements: ["Taught 50+ students", "Developed interactive curriculum", "95% student satisfaction rate"]
    }
  ];

  // useEffect(() => {
  //   gsap.to(titleRef.current, {
  //     text: "Work Experience",
  //     duration: 2,
  //     ease: "none",
  //     scrollTrigger: {
  //       trigger: titleRef.current,
  //       start: "top 80%",
  //       toggleActions: "play none none reverse"
  //     }
  //   });
  // }, []);

  return (
    <section id="work" className="py-20 px-6 bg-stone-100">
      <div className="max-w-5xl mx-auto">
        <motion.h2 
          // ref={titleRef} // Keeping ref for potential typing animation
          className="text-4xl md:text-5xl mb-16 text-center font-semibold"
          style={{ fontFamily: "'Poppins', sans-serif" }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Work Experience
        </motion.h2>
        
        <div className="grid gap-8 md:gap-12">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              className="bg-stone-50 p-8 rounded-xl shadow-sm border border-stone-200 hover:shadow-md transition-shadow"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-semibold mb-1" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {exp.position}
                  </h3>
                  <p className="text-lg text-stone-600 mb-3 font-medium">{exp.company}</p>
                </div>
                <span className="text-sm text-stone-500 bg-stone-200 px-3 py-1 rounded-full whitespace-nowrap">
                  {exp.period}
                </span>
              </div>
              
              {/* <TypewriterText  // Keeping component for potential future use
                text={exp.description}
                delay={2 + index * 0.5}
                className="text-lg text-stone-700 leading-relaxed mb-6"
              /> */}
              <p className="text-lg text-stone-700 leading-relaxed mb-6">
                {exp.description}
              </p>
              
              <div className="space-y-2">
                <h4 className="text-lg font-medium text-stone-800 mb-3">Key Achievements:</h4>
                {exp.achievements.map((achievement, achIndex) => (
                  <motion.div
                    key={achIndex}
                    className="flex items-center space-x-2"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.3 + achIndex * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="w-2 h-2 bg-stone-900 rounded-full" />
                    <span className="text-stone-700">{achievement}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          className="mt-20 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          viewport={{ once: true }}
        >
          {/* <TypewriterText  // Keeping component for potential future use
            text="Ready to bring my passion for technology and proven track record of success to new challenges. Let's build something amazing together."
            delay={5}
            className="text-xl text-stone-600 max-w-3xl mx-auto leading-relaxed mb-8"
          /> */}
          <p className="text-xl text-stone-600 max-w-3xl mx-auto leading-relaxed mb-8">
            Ready to bring my passion for technology and proven track record of success to new challenges. Let's build something amazing together.
          </p>
          
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 8 }}
            viewport={{ once: true }}
          >
            <motion.button
              className="px-8 py-3 bg-stone-900 text-stone-50 rounded-full hover:bg-stone-800 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Download Resume
            </motion.button>
            <motion.button
              className="px-8 py-3 border-2 border-stone-900 text-stone-900 rounded-full hover:bg-stone-900 hover:text-stone-50 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Contact Me
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

// Keeping TypewriterText component for potential future use
// function TypewriterText({ text, delay, className }) {
//   const textRef = useRef(null);

//   useEffect(() => {
//     gsap.to(textRef.current, {
//       text: text,
//       duration: text.length * 0.03,
//       ease: "none",
//       scrollTrigger: {
//         trigger: textRef.current,
//         start: "top 85%",
//         toggleActions: "play none none reverse"
//       },
//       delay: delay
//     });
//   }, [text, delay]);

//   return <p ref={textRef} className={className} />;
// }