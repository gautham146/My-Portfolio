import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Users, Award, BookOpen, PenTool, FolderOpen, X, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

gsap.registerPlugin(ScrollTrigger);

const RefinedExtracurriculars = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const fileRefs = useRef<HTMLDivElement[]>([]);
  const [selectedFile, setSelectedFile] = useState<number | null>(null);

  const activities = [
    {
      title: "Computer Science Club",
      role: "Vice President",
      description: "Leading a team of 50+ students in organizing coding competitions, workshops, and tech talks. Coordinated hackathons that attracted participants from 15+ colleges.",
      fullDescription: "As Vice President of the Computer Science Club, I've spearheaded the transformation of our organization into one of the most active tech communities on campus. My leadership has involved strategic planning, team coordination, and creating an inclusive environment where students from all backgrounds can explore technology. We've organized major hackathons, guest lectures from industry professionals, and collaborative coding sessions that have significantly enhanced the learning experience for our members.",
      period: "2023 - Present",
      icon: Users,
      metrics: ["50+ Members", "15+ Colleges", "12 Events"],
      fileType: "leadership.exe",
      bgColor: "bg-blue-50",
      accentColor: "bg-blue-500",
      image: "https://images.unsplash.com/photo-1753613648137-602c669cbe07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHNjaWVuY2UlMjBjb2RpbmclMjBzdHVkZW50c3xlbnwxfHx8fDE3NTkwMDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Debate Society",
      role: "Active Member",
      description: "Participated in inter-college debate competitions, developing critical thinking and public speaking skills while exploring contemporary issues.",
      fullDescription: "My involvement in the Debate Society has been instrumental in developing my communication and analytical skills. Through rigorous training sessions and competitive debates, I've learned to articulate complex ideas clearly, think critically under pressure, and defend positions with well-researched arguments. This experience has not only improved my public speaking abilities but also enhanced my capacity to understand multiple perspectives on challenging topics.",
      period: "2022 - Present",
      icon: Award,
      metrics: ["8 Competitions", "3 Awards", "2 Years"],
      fileType: "speaking.pdf",
      bgColor: "bg-purple-50",
      accentColor: "bg-purple-500",
      image: "https://images.unsplash.com/photo-1709377418835-304afc0e064a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWJhdGUlMjBjb21wZXRpdGlvbiUyMHB1YmxpYyUyMHNwZWFraW5nfGVufDF8fHx8MTc1OTAwNjAzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "Community Service Initiative",
      role: "Volunteer Coordinator",
      description: "Organized digital literacy programs for underprivileged communities, teaching basic computer skills to 100+ individuals.",
      fullDescription: "Coordinating community service initiatives has been one of my most rewarding experiences. I've designed and implemented comprehensive digital literacy programs that bridge the technology gap in underserved communities. My role involved curriculum development, volunteer training, resource management, and direct teaching. The impact has been profound - seeing individuals gain confidence with technology and open new opportunities for themselves reinforces my belief in technology's power to create positive social change.",
      period: "2022 - 2024",
      icon: BookOpen,
      metrics: ["100+ Students", "5 Programs", "24 Months"],
      fileType: "community.docx",
      bgColor: "bg-green-50",
      accentColor: "bg-green-500",
      image: "https://images.unsplash.com/photo-1743793174491-bcbdf1882ad5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBzZXJ2aWNlJTIwdGVhY2hpbmclMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1OTAwNjA0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      title: "University Tech Magazine",
      role: "Contributing Writer",
      description: "Writing articles about emerging technologies, startup culture, and the intersection of tech and society for the monthly publication.",
      fullDescription: "Contributing to the University Tech Magazine has allowed me to explore the intersection of technology and society through written expression. My articles cover emerging technologies, startup ecosystems, and the societal implications of digital transformation. This role has sharpened my research skills, taught me to translate complex technical concepts for diverse audiences, and provided a platform to voice perspectives on the future of technology. Each piece requires extensive research, interviews with industry professionals, and careful consideration of multiple viewpoints.",
      period: "2023 - Present",
      icon: PenTool,
      metrics: ["15 Articles", "10K+ Readers", "Monthly"],
      fileType: "writing.txt",
      bgColor: "bg-orange-50",
      accentColor: "bg-orange-500",
      image: "https://images.unsplash.com/photo-1663025292954-dd09983bd945?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3cml0aW5nJTIwbWFnYXppbmUlMjBqb3VybmFsaXNtJTIwdGVjaHxlbnwxfHx8fDE3NTkwMDYwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Stagger file icon animations
    fileRefs.current.forEach((file, index) => {
      if (!file) return;
      
      ScrollTrigger.create({
        trigger: file,
        start: "top 85%",
        onEnter: () => {
          gsap.fromTo(file, 
            { y: 60, opacity: 0, rotateY: -25 },
            {
              y: 0,
              opacity: 1,
              rotateY: 0,
              duration: 1,
              delay: index * 0.15,
              ease: "power3.out"
            }
          );
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const handleFileClick = (index: number) => {
    setSelectedFile(selectedFile === index ? null : index);
  };

  return (
    <section id="extracurriculars" ref={sectionRef} className="py-32 relative bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Leadership & Impact
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto font-light leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Click on any file to explore my leadership journey and community impact.
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* File browser interface */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-lg overflow-hidden">
          
          {/* Browser header */}
          <div className="bg-gray-100 px-6 py-4 border-b border-gray-200 flex items-center gap-3">
            <div className="flex gap-2">
              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <FolderOpen className="w-4 h-4" />
              <span className="text-sm font-light">Leadership & Impact</span>
            </div>
          </div>

          {/* File grid */}
          <div className="p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {activities.map((activity, index) => (
                <motion.div
                  key={activity.title}
                  ref={(el) => el && (fileRefs.current[index] = el)}
                  className="group cursor-pointer"
                  onClick={() => handleFileClick(index)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <div className={`${activity.bgColor} p-6 rounded-xl border-2 border-transparent hover:border-gray-300 transition-all duration-300 text-center group-hover:shadow-lg`}>
                    
                    {/* File icon */}
                    <div className="relative mb-4">
                      <div className="w-16 h-20 mx-auto relative">
                        {/* File shape */}
                        <div className="w-full h-full bg-white rounded-lg shadow-sm border border-gray-200 relative overflow-hidden">
                          <div className="absolute top-0 right-0 w-4 h-4">
                            <div className="w-full h-full bg-gray-100 transform rotate-45 translate-x-2 -translate-y-2"></div>
                          </div>
                          <div className={`absolute bottom-0 left-0 right-0 h-2 ${activity.accentColor} opacity-80`}></div>
                          <div className="flex items-center justify-center h-full">
                            <activity.icon className="w-6 h-6 text-gray-600 group-hover:text-gray-800 transition-colors duration-300" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* File name */}
                    <p className="text-sm font-medium text-gray-800 mb-2 truncate">
                      {activity.title}
                    </p>
                    <p className="text-xs text-gray-500 font-light">
                      {activity.fileType}
                    </p>

                    {/* Selection indicator */}
                    {selectedFile === index && (
                      <motion.div
                        className="absolute inset-0 border-2 border-blue-500 rounded-xl bg-blue-50/30"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2 }}
                      />
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Expanded file view */}
        <AnimatePresence>
          {selectedFile !== null && (() => {
            const selectedActivity = activities[selectedFile];
            const IconComponent = selectedActivity.icon;
            
            return (
              <motion.div
                className="mt-8 bg-white rounded-2xl border border-gray-200 shadow-lg overflow-hidden"
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -30, scale: 0.95 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
              >
                {/* Header */}
                <div className="bg-gray-100 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <IconComponent className="w-5 h-5 text-gray-600" />
                    <span className="font-medium text-gray-800">{selectedActivity.title}</span>
                    <span className="text-sm text-gray-500">• {selectedActivity.role}</span>
                  </div>
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="p-1 hover:bg-gray-200 rounded-lg transition-colors duration-200"
                  >
                    <X className="w-4 h-4 text-gray-600" />
                  </button>
                </div>

                {/* Content */}
                <div className="p-8">
                  <div className="flex flex-col lg:flex-row gap-8">
                    
                    {/* Image */}
                    <div className="lg:w-1/2">
                      <div className="aspect-video rounded-xl overflow-hidden">
                        <ImageWithFallback
                          src={selectedActivity.image}
                          alt={selectedActivity.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    </div>

                    {/* Details */}
                    <div className="lg:w-1/2 space-y-6">
                      
                      {/* Period */}
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                          {selectedActivity.period}
                        </span>
                      </div>

                      {/* Description */}
                      <div>
                        <h4 className="text-lg font-medium text-gray-800 mb-3">Overview</h4>
                        <p className="text-gray-600 leading-relaxed font-light">
                          {selectedActivity.fullDescription}
                        </p>
                      </div>

                      {/* Metrics */}
                      <div>
                        <h4 className="text-lg font-medium text-gray-800 mb-3">Impact Metrics</h4>
                        <div className="grid grid-cols-3 gap-4">
                          {selectedActivity.metrics.map((metric, metricIndex) => (
                            <div key={metricIndex} className="text-center p-3 bg-gray-50 rounded-lg">
                              <div className="text-lg font-medium text-gray-800">
                                {metric.split(' ')[0]}
                              </div>
                              <div className="text-xs text-gray-500 uppercase tracking-wider">
                                {metric.split(' ').slice(1).join(' ')}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Learn more link */}
                      <div className="pt-4">
                        <button className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors duration-200">
                          <span className="text-sm font-medium">Explore in detail</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })()}
        </AnimatePresence>

        {/* Philosophy section */}
        <motion.div
          className="mt-24 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="max-w-3xl mx-auto">
            <p className="text-xl text-gray-600 font-light leading-relaxed italic">
              "Leadership isn't about being in charge. It's about taking care of those in your charge 
              and creating opportunities for others to grow."
            </p>
            <div className="w-12 h-px bg-gray-400 mx-auto mt-8" />
          </div>
        </motion.div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-32 left-16 w-16 h-px bg-gray-200 opacity-40" />
      <div className="absolute bottom-24 right-16 w-px h-20 bg-gray-200 opacity-40" />
    </section>
  );
};

export default RefinedExtracurriculars;