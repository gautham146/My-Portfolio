import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  // const titleRef = useRef(null); // Keeping refs for potential typing animation
  // const descRef = useRef(null);
  // const interestsRef = useRef(null);
  // const hobbiesRef = useRef(null);

  // Typing animation function (kept for future use)
  // useEffect(() => {
  //   const tl = gsap.timeline({
  //     scrollTrigger: {
  //       trigger: titleRef.current,
  //       start: "top 80%",
  //       end: "bottom 20%",
  //       toggleActions: "play none none reverse"
  //     }
  //   });

  //   tl.to(titleRef.current, {
  //     text: "About Me",
  //     duration: 1.5,
  //     ease: "none"
  //   })
  //   .to(descRef.current, {
  //     text: "I'm a passionate student who believes in the power of technology to transform lives. When I'm not coding or studying, you'll find me exploring new ideas, collaborating on innovative projects, and constantly learning about the world around me.",
  //     duration: 3,
  //     ease: "none"
  //   }, "+=0.3")
  //   .to(interestsRef.current, {
  //     text: "My interests span across artificial intelligence, web development, sustainable technology, and human-computer interaction. I'm fascinated by how we can use technology to solve real-world problems and create more inclusive digital experiences.",
  //     duration: 3.2,
  //     ease: "none"
  //   }, "+=0.5")
  //   .to(hobbiesRef.current, {
  //     text: "Outside of tech, I enjoy photography, playing guitar, hiking, reading sci-fi novels, and experimenting with new recipes in the kitchen. I believe these diverse experiences fuel my creativity and bring fresh perspectives to my work.",
  //     duration: 3.5,
  //     ease: "none"
  //   }, "+=0.4");
  // }, []);

  return (
    <section className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <motion.h2 
          // ref={titleRef} // Keeping ref for potential typing animation
          className="text-4xl md:text-5xl mb-12 text-center font-semibold"
          style={{ fontFamily: "'Poppins', sans-serif" }}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          About Me
        </motion.h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl mb-6 font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Who I Am
            </h3>
            {/* <p ref={descRef} className="text-lg leading-relaxed text-stone-700 mb-8" /> */}
            <p className="text-lg leading-relaxed text-stone-700 mb-8">
              I'm a passionate student who believes in the power of technology to transform lives. When I'm not coding or studying, you'll find me exploring new ideas, collaborating on innovative projects, and constantly learning about the world around me.
            </p>
            
            <h3 className="text-2xl mb-6 font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              What Drives Me
            </h3>
            {/* <p ref={interestsRef} className="text-lg leading-relaxed text-stone-700" /> */}
            <p className="text-lg leading-relaxed text-stone-700">
              My interests span across artificial intelligence, web development, sustainable technology, and human-computer interaction. I'm fascinated by how we can use technology to solve real-world problems and create more inclusive digital experiences.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl mb-6 font-semibold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Beyond Technology
            </h3>
            {/* <p ref={hobbiesRef} className="text-lg leading-relaxed text-stone-700 mb-8" /> */}
            <p className="text-lg leading-relaxed text-stone-700 mb-8">
              Outside of tech, I enjoy photography, playing guitar, hiking, reading sci-fi novels, and experimenting with new recipes in the kitchen. I believe these diverse experiences fuel my creativity and bring fresh perspectives to my work.
            </p>
            
            <div className="flex flex-wrap gap-3 mt-8">
              {['Photography', 'Guitar', 'Hiking', 'Cooking', 'Reading', 'Travel'].map((hobby, index) => (
                <motion.span
                  key={hobby}
                  className="px-4 py-2 bg-stone-200 text-stone-800 rounded-full text-sm"
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.1 }}
                >
                  {hobby}
                </motion.span>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}