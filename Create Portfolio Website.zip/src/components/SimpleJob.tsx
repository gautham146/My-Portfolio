import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Briefcase, Calendar, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

gsap.registerPlugin(ScrollTrigger);

const SimpleJob = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const jobExperience = {
    company: "TechStart Solutions",
    position: "Frontend Developer Intern",
    location: "San Francisco, CA",
    period: "June 2024 - August 2024",
    description: "Developed responsive web applications using React and TypeScript. Collaborated with design teams to implement pixel-perfect UI components and improved application performance by 40%. Worked in an agile environment with cross-functional teams to deliver high-quality software solutions.",
    responsibilities: [
      "Built and maintained reusable React components for the design system",
      "Optimized application bundle size, reducing load time by 25%",
      "Implemented dark mode feature across the entire application",
      "Collaborated with UX designers to ensure pixel-perfect implementations",
      "Participated in code reviews and contributed to technical documentation"
    ],
    achievements: [
      "Reduced bundle size by 25% through code splitting and lazy loading",
      "Improved application performance score from 65 to 92",
      "Received outstanding intern award for technical contributions"
    ],
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjB3b3JrJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTkwOTc2ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  };

  useEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const content = contentRef.current;
    
    if (!section || !image || !content) return;

    // Parallax effect for image
    ScrollTrigger.create({
      trigger: section,
      start: "top bottom",
      end: "bottom top",
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.to(image, {
          y: progress * 50,
          duration: 0.3
        });
      }
    });

    // Fade in animation
    gsap.fromTo(image,
      { opacity: 0, x: -50 },
      {
        opacity: 1,
        x: 0,
        duration: 1.2,
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
        }
      }
    );

    gsap.fromTo(content,
      { opacity: 0, x: 50 },
      {
        opacity: 1,
        x: 0,
        duration: 1.2,
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
        }
      }
    );

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section id="work" ref={sectionRef} className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Work Experience
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto font-light leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Professional journey shaping technical expertise and problem-solving skills
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* Job Overview - Similar to About Section */}
        <div className="mb-24">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            
            {/* Left - Text Content */}
            <div ref={contentRef} className="space-y-6">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <Briefcase className="w-5 h-5" />
                  <span className="text-sm uppercase tracking-wider font-light">Professional Experience</span>
                </div>
                
                <h3 className="text-3xl md:text-4xl text-gray-900" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {jobExperience.position}
                </h3>
                
                <div className="flex flex-col gap-2 text-gray-600">
                  <div className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
                    <span className="text-lg">{jobExperience.company}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{jobExperience.period}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{jobExperience.location}</span>
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-gray-700 leading-relaxed font-light text-lg">
                {jobExperience.description}
              </p>
            </div>

            {/* Right - Image */}
            <div ref={imageRef} className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.06)]">
                <ImageWithFallback
                  src={jobExperience.image}
                  alt={jobExperience.company}
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative element */}
              <div className="absolute -bottom-6 -right-6 w-32 h-32 border border-gray-200 rounded-2xl -z-10" />
            </div>
          </div>
        </div>

        {/* Detailed Content */}
        <div className="grid md:grid-cols-2 gap-12">
          
          {/* Responsibilities */}
          <div>
            <h4 className="text-xl text-gray-900 mb-4 font-light" style={{ fontFamily: "'Playfair Display', serif" }}>
              Key Responsibilities
            </h4>
            <div className="space-y-3">
              {jobExperience.responsibilities.map((responsibility, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-1.5 h-1.5 bg-gray-600 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700 text-sm font-light leading-relaxed">
                    {responsibility}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Achievements */}
          <div>
            <h4 className="text-xl text-gray-900 mb-4 font-light" style={{ fontFamily: "'Playfair Display', serif" }}>
              Key Achievements
            </h4>
            <div className="space-y-3">
              {jobExperience.achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl"
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-1.5 h-1.5 bg-gray-800 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700 text-sm font-light leading-relaxed">
                    {achievement}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-20 left-16 w-12 h-px bg-gray-200 opacity-30" />
      <div className="absolute bottom-32 right-16 w-px h-16 bg-gray-200 opacity-30" />
    </section>
  );
};

export default SimpleJob;
