import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TextPlugin } from 'gsap/TextPlugin';

gsap.registerPlugin(ScrollTrigger, TextPlugin);

const AdvancedHero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const nameRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const descRef = useRef<HTMLDivElement>(null);
  const circleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hero = heroRef.current;
    const name = nameRef.current;
    const title = titleRef.current;
    const desc = descRef.current;
    const circle = circleRef.current;

    if (!hero || !name || !title || !desc || !circle) return;

    // Initial animations
    gsap.set([name, title, desc], { y: 100, opacity: 0 });
    gsap.set(circle, { scale: 0, rotation: -180 });

    const tl = gsap.timeline({ delay: 0.5 });
    
    tl.to(circle, {
      scale: 1,
      rotation: 0,
      duration: 1.5,
      ease: "back.out(1.7)"
    })
    .to(name, {
      y: 0,
      opacity: 1,
      duration: 1,
      ease: "power3.out"
    }, "-=1")
    .to(title, {
      y: 0,
      opacity: 1,
      duration: 1,
      ease: "power3.out"
    }, "-=0.7")
    .to(desc, {
      y: 0,
      opacity: 1,
      duration: 1,
      ease: "power3.out"
    }, "-=0.7");

    // Scroll-triggered animations
    ScrollTrigger.create({
      trigger: hero,
      start: "top top",
      end: "bottom top",
      scrub: 1,
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.to(name, {
          y: -progress * 200,
          scale: 1 - progress * 0.2,
          duration: 0.3
        });
        gsap.to(title, {
          y: -progress * 150,
          opacity: 1 - progress * 1.5,
          duration: 0.3
        });
        gsap.to(circle, {
          scale: 1 + progress * 0.5,
          opacity: 1 - progress * 0.8,
          rotation: progress * 180,
          duration: 0.3
        });
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <div id="hero" ref={heroRef} className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated background circle */}
      <div
        ref={circleRef}
        className="absolute w-96 h-96 rounded-full opacity-20"
        style={{
          background: 'conic-gradient(from 0deg, rgba(120, 119, 198, 0.6), rgba(255, 183, 77, 0.5), rgba(255, 77, 77, 0.5), rgba(120, 198, 121, 0.5), rgba(198, 120, 221, 0.5), rgba(77, 196, 255, 0.5), rgba(120, 119, 198, 0.6))',
          filter: 'blur(2px)',
        }}
      />

      <div className="text-center z-10 max-w-4xl mx-auto px-6">
        {/* Name with gradient */}
        <motion.div
          ref={nameRef}
          className="relative"
        >
          <h1 className="text-8xl md:text-9xl font-bold text-gradient mb-4 tracking-tight">
            Gautham
          </h1>
          <h1 className="text-8xl md:text-9xl font-bold text-gradient-warm mb-8 tracking-tight">
            Girish
          </h1>
        </motion.div>

        {/* Animated title */}
        <motion.div
          ref={titleRef}
          className="mb-8"
        >
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent flex-1" />
            <h2 className="text-2xl md:text-3xl font-light text-gradient-cool tracking-wider">
              Creative Developer
            </h2>
            <div className="h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent flex-1" />
          </div>
        </motion.div>

        {/* Description */}
        <motion.div
          ref={descRef}
          className="max-w-2xl mx-auto"
        >
          <p className="text-lg md:text-xl text-gray-600 leading-relaxed mb-12">
            Crafting digital experiences that blend innovative design with cutting-edge technology. 
            Passionate about creating immersive web applications that push the boundaries of what's possible.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
            <motion.button
              className="group relative px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full overflow-hidden transition-all duration-300 hover:scale-105"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="relative z-10">View My Work</span>
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.button>

            <motion.button
              className="group relative px-8 py-4 border-2 border-gray-800 text-gray-800 rounded-full overflow-hidden transition-all duration-300 hover:text-white"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="relative z-10">Get In Touch</span>
              <div className="absolute inset-0 bg-gray-800 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2, duration: 1 }}
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-sm text-gray-500 tracking-wider">SCROLL</span>
          <motion.div
            className="w-px h-8 bg-gradient-to-b from-purple-500 to-transparent"
            animate={{ scaleY: [1, 0.5, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      </motion.div>

      {/* Floating elements */}
      {Array.from({ length: 5 }, (_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-purple-400 rounded-full opacity-60"
          style={{
            left: `${20 + i * 15}%`,
            top: `${30 + Math.sin(i) * 20}%`,
          }}
          animate={{
            y: [-20, 20, -20],
            x: [-10, 10, -10],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 4 + i,
            repeat: Infinity,
            delay: i * 0.5,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
};

export default AdvancedHero;