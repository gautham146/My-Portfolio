import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const AdvancedSkills = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement[]>([]);
  const circleRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: 'React & Next.js', level: 95, category: 'Frontend', color: '#61DAFB' },
    { name: 'TypeScript', level: 90, category: 'Language', color: '#3178C6' },
    { name: 'Node.js', level: 85, category: 'Backend', color: '#68A063' },
    { name: 'GSAP & Animations', level: 88, category: 'Animation', color: '#88CE02' },
    { name: 'Three.js', level: 75, category: 'WebGL', color: '#000000' },
    { name: 'Python', level: 82, category: 'Language', color: '#3776AB' },
    { name: 'UI/UX Design', level: 85, category: 'Design', color: '#FF6B6B' },
    { name: 'WebGL & Shaders', level: 70, category: 'Graphics', color: '#FF4088' },
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Animate skill bars on scroll
    skillsRef.current.forEach((skill, index) => {
      if (!skill) return;
      
      const bar = skill.querySelector('.skill-bar');
      const percentage = skill.querySelector('.skill-percentage');
      const level = skills[index].level;
      
      if (!bar || !percentage) return;

      ScrollTrigger.create({
        trigger: skill,
        start: "top 80%",
        onEnter: () => {
          gsap.fromTo(bar, 
            { scaleX: 0 },
            { 
              scaleX: level / 100, 
              duration: 1.5, 
              delay: index * 0.1,
              ease: "power3.out"
            }
          );
          
          gsap.fromTo(percentage,
            { textContent: 0 },
            {
              textContent: level,
              duration: 1.5,
              delay: index * 0.1,
              snap: { textContent: 1 },
              ease: "power3.out"
            }
          );
        }
      });
    });

    // Floating circle animation
    const circle = circleRef.current;
    if (circle) {
      ScrollTrigger.create({
        trigger: section,
        start: "top bottom",
        end: "bottom top",
        scrub: 1,
        onUpdate: (self) => {
          const progress = self.progress;
          gsap.to(circle, {
            rotation: progress * 360,
            scale: 1 + progress * 0.3,
            duration: 0.3
          });
        }
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section id="skills" ref={sectionRef} className="min-h-screen py-32 relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-20">
          <motion.h2
            className="text-6xl md:text-7xl font-bold text-gradient mb-6"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Skills & Expertise
          </motion.h2>
          <motion.p
            className="text-xl text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            A blend of technical proficiency and creative vision, 
            constantly evolving with the latest technologies.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Skills list */}
          <div className="space-y-8">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                ref={(el) => el && (skillsRef.current[index] = el)}
                className="group"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: skill.color }}
                    />
                    <span className="font-semibold text-lg">{skill.name}</span>
                    <span className="text-sm text-gray-500 px-2 py-1 bg-gray-100 rounded-full">
                      {skill.category}
                    </span>
                  </div>
                  <span className="text-xl font-bold text-gradient">
                    <span className="skill-percentage">0</span>%
                  </span>
                </div>
                
                <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="skill-bar absolute inset-y-0 left-0 rounded-full transition-all duration-300 group-hover:shadow-lg"
                    style={{ 
                      backgroundColor: skill.color,
                      transformOrigin: 'left',
                      transform: 'scaleX(0)'
                    }}
                  />
                  <div 
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${skill.color}40, transparent)`
                    }}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Visualization */}
          <div className="relative flex items-center justify-center">
            {/* Central circle */}
            <div
              ref={circleRef}
              className="relative w-80 h-80 rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-white/30"
            >
              {/* Skill orbits */}
              {skills.map((skill, index) => {
                const angle = (index * 360) / skills.length;
                const radius = 120;
                const x = Math.cos((angle * Math.PI) / 180) * radius;
                const y = Math.sin((angle * Math.PI) / 180) * radius;
                
                return (
                  <motion.div
                    key={`orbit-${skill.name}`}
                    className="absolute w-12 h-12 rounded-full glass-effect flex items-center justify-center"
                    style={{
                      left: '50%',
                      top: '50%',
                      transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                    }}
                    initial={{ scale: 0, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    transition={{ 
                      duration: 0.8, 
                      delay: index * 0.1,
                      type: "spring",
                      stiffness: 100
                    }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.2 }}
                  >
                    <div
                      className="w-6 h-6 rounded-full"
                      style={{ backgroundColor: skill.color }}
                    />
                  </motion.div>
                );
              })}

              {/* Center content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <div className="text-4xl font-bold text-gradient mb-2">8+</div>
                <div className="text-sm text-gray-600 font-medium">Technologies</div>
                <div className="text-xs text-gray-500 mt-1">& Growing</div>
              </div>

              {/* Rotating rings */}
              <div className="absolute inset-4 border border-dashed border-purple-300 rounded-full animate-spin" style={{ animationDuration: '20s' }} />
              <div className="absolute inset-8 border border-dashed border-pink-300 rounded-full animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
            </div>

            {/* Floating particles */}
            {Array.from({ length: 8 }, (_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full"
                style={{
                  backgroundColor: skills[i]?.color || '#667eea',
                  left: `${30 + Math.random() * 40}%`,
                  top: `${30 + Math.random() * 40}%`,
                }}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5],
                  x: [0, Math.random() * 40 - 20, 0],
                  y: [0, Math.random() * 40 - 20, 0],
                }}
                transition={{
                  duration: 4 + Math.random() * 4,
                  repeat: Infinity,
                  delay: i * 0.5,
                  ease: "easeInOut"
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-xl animate-float" />
      <div className="absolute bottom-10 right-10 w-32 h-32 bg-gradient-to-br from-pink-400/20 to-orange-400/20 rounded-full blur-xl animate-float" style={{ animationDelay: '3s' }} />
    </section>
  );
};

export default AdvancedSkills;