import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Calendar, Trophy, Shield, ExternalLink, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const ElegantCertificates = () => {
  const [selectedCertificate, setSelectedCertificate] = useState<number | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const certificates = [
    {
      id: 1,
      name: "Leadership Excellence Certificate",
      issuer: "Student Affairs Office",
      date: "May 2024",
      category: "Leadership",
      description: "Awarded for exceptional leadership skills demonstrated through successful management of multiple student organizations and community initiatives.",
      image: "https://images.unsplash.com/photo-1660795468951-0b37051eb1b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJ0aWZpY2F0ZSUyMGF3YXJkJTIwYWNoaWV2ZW1lbnR8ZW58MXx8fHwxNzU5MDc0NTYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Team Management", "Strategic Planning", "Communication", "Project Coordination"],
      credentialId: "LEX-2024-001",
      bgColor: "bg-blue-50",
      accentColor: "bg-blue-500",
      borderColor: "border-blue-200"
    },
    {
      id: 2,
      name: "Public Speaking Excellence Award",
      issuer: "National Debate Association",
      date: "December 2023",
      category: "Communication",
      description: "Recognition for outstanding public speaking abilities and winning multiple inter-college debate competitions.",
      image: "https://images.unsplash.com/photo-1658235081452-c2ded30b8d9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXBsb21hJTIwZ3JhZHVhdGlvbiUyMGNlcnRpZmljYXRlfGVufDF8fHx8MTc1OTA3NDU2OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Public Speaking", "Critical Thinking", "Argumentation", "Research"],
      credentialId: "PSE-2023-042",
      bgColor: "bg-purple-50",
      accentColor: "bg-purple-500",
      borderColor: "border-purple-200"
    },
    {
      id: 3,
      name: "Community Impact Award",
      issuer: "City Volunteer Council",
      date: "August 2024",
      category: "Service",
      description: "Honored for establishing digital literacy programs and creating lasting positive impact in underserved communities.",
      image: "https://images.unsplash.com/photo-1715173679369-18006e84d6a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBjZXJ0aWZpY2F0aW9uJTIwZG9jdW1lbnR8ZW58MXx8fHwxNzU5MDc0NTcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Community Outreach", "Program Development", "Social Impact", "Volunteer Management"],
      credentialId: "CIA-2024-089",
      bgColor: "bg-green-50",
      accentColor: "bg-green-500",
      borderColor: "border-green-200"
    },
    {
      id: 4,
      name: "Excellence in Technical Writing",
      issuer: "University Press Association",
      date: "September 2024",
      category: "Technical",
      description: "Awarded for outstanding technical writing abilities and successful multimedia content strategy that increased engagement by 200%.",
      image: "https://images.unsplash.com/photo-1575466526763-e0199e8c3d7e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWFkZXJzaGlwJTIwcmVjb2duaXRpb24lMjBob25vcnxlbnwxfHx8fDE3NTkwNzQ1ODB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Technical Writing", "Content Strategy", "Media Production", "Research"],
      credentialId: "ETW-2024-156",
      bgColor: "bg-orange-50",
      accentColor: "bg-orange-500",
      borderColor: "border-orange-200"
    },
    {
      id: 5,
      name: "Digital Innovation Certificate",
      issuer: "Tech Innovation Institute",
      date: "November 2024",
      category: "Technology",
      description: "Certification for innovative approaches to digital solutions and successful implementation of technology-driven projects.",
      image: "https://images.unsplash.com/photo-1621036579842-9080c7119f67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobmljYWwlMjBza2lsbHMlMjBjZXJ0aWZpY2F0aW9ufGVufDF8fHx8MTc1OTA3NDU4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Digital Innovation", "Project Management", "Technology Integration", "Problem Solving"],
      credentialId: "DIC-2024-203",
      bgColor: "bg-indigo-50",
      accentColor: "bg-indigo-500",
      borderColor: "border-indigo-200"
    },
    {
      id: 6,
      name: "Academic Excellence Honor",
      issuer: "Dean's Office",
      date: "June 2024",
      category: "Academic",
      description: "Recognition for maintaining exceptional academic performance while actively contributing to student life and community service.",
      image: "https://images.unsplash.com/photo-1660795468951-0b37051eb1b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY2FkZW1pYyUyMGV4Y2VsbGVuY2UlMjBhd2FyZHxlbnwxfHx8fDE3NTkwNzQ1NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      skills: ["Academic Research", "Time Management", "Critical Analysis", "Scholarly Writing"],
      credentialId: "AEH-2024-098",
      bgColor: "bg-teal-50",
      accentColor: "bg-teal-500",
      borderColor: "border-teal-200"
    }
  ];

  const openModal = (index: number) => {
    setSelectedCertificate(index);
    setCurrentIndex(index);
  };

  const closeModal = () => {
    setSelectedCertificate(null);
  };

  const nextCertificate = () => {
    const newIndex = (currentIndex + 1) % certificates.length;
    setCurrentIndex(newIndex);
    setSelectedCertificate(newIndex);
  };

  const prevCertificate = () => {
    const newIndex = (currentIndex - 1 + certificates.length) % certificates.length;
    setCurrentIndex(newIndex);
    setSelectedCertificate(newIndex);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50/30" id="certificates">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-12 h-px bg-gray-300"></div>
            <Trophy className="w-8 h-8 text-gray-600" />
            <div className="w-12 h-px bg-gray-300"></div>
          </div>
          <h2 className="text-5xl font-light text-gray-900 mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Certificates & Recognition
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
            A collection of achievements and certifications that showcase expertise, leadership, and commitment to excellence across various domains.
          </p>
        </motion.div>

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certificates.map((certificate, index) => (
            <motion.div
              key={certificate.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`${certificate.bgColor} rounded-2xl overflow-hidden border ${certificate.borderColor} hover:shadow-xl transition-all duration-300 cursor-pointer group`}
              onClick={() => openModal(index)}
            >
              {/* Certificate Image */}
              <div className="aspect-video overflow-hidden relative">
                <ImageWithFallback
                  src={certificate.image}
                  alt={certificate.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {/* Category Badge */}
                <div className={`absolute top-4 left-4 ${certificate.accentColor} text-white px-3 py-1 rounded-full text-sm font-medium`}>
                  {certificate.category}
                </div>
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center">
                  <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform scale-75 group-hover:scale-100 transition-all duration-300">
                    <ExternalLink className="w-5 h-5 text-gray-700" />
                  </div>
                </div>
              </div>

              {/* Certificate Info */}
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {certificate.name}
                </h3>
                <p className="text-sm text-gray-600 mb-3">
                  {certificate.issuer}
                </p>
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-500">{certificate.date}</span>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed mb-4 line-clamp-2">
                  {certificate.description}
                </p>
                
                {/* Skills Tags */}
                <div className="flex flex-wrap gap-2">
                  {certificate.skills.slice(0, 2).map((skill, skillIndex) => (
                    <span key={skillIndex} className="px-2 py-1 bg-white/70 text-xs text-gray-600 rounded-md">
                      {skill}
                    </span>
                  ))}
                  {certificate.skills.length > 2 && (
                    <span className="px-2 py-1 bg-white/70 text-xs text-gray-500 rounded-md">
                      +{certificate.skills.length - 2} more
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Certificate Modal */}
        <AnimatePresence>
          {selectedCertificate !== null && (
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Backdrop */}
              <motion.div
                className="absolute inset-0 bg-black/80 backdrop-blur-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={closeModal}
              />

              {/* Modal Content */}
              <motion.div
                className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                {(() => {
                  const certificate = certificates[currentIndex];
                  return (
                    <>
                      {/* Header */}
                      <div className="absolute top-0 left-0 right-0 z-10 bg-white/95 backdrop-blur-md border-b border-gray-200">
                        <div className="flex items-center justify-between p-6">
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 ${certificate.accentColor} rounded-xl flex items-center justify-center`}>
                              <Award className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <h1 className="text-2xl font-semibold text-gray-900" style={{ fontFamily: "'Playfair Display', serif" }}>
                                Certificate Details
                              </h1>
                              <p className="text-sm text-gray-600">{certificate.category} • {certificate.date}</p>
                            </div>
                          </div>
                          <button
                            onClick={closeModal}
                            className="w-12 h-12 flex items-center justify-center hover:bg-gray-100 rounded-xl transition-colors duration-200"
                          >
                            <X className="w-6 h-6 text-gray-600" />
                          </button>
                        </div>
                      </div>

                      {/* Main Content */}
                      <div className="pt-24 h-full flex flex-col lg:flex-row">
                        
                        {/* Left Side - Image */}
                        <div className="lg:w-1/2 h-64 lg:h-full relative overflow-hidden">
                          <ImageWithFallback
                            src={certificate.image}
                            alt={certificate.name}
                            className="w-full h-full object-cover"
                          />
                          {/* Navigation Buttons */}
                          <button
                            onClick={prevCertificate}
                            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-200"
                          >
                            <ChevronLeft className="w-6 h-6 text-gray-700" />
                          </button>
                          <button
                            onClick={nextCertificate}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-200"
                          >
                            <ChevronRight className="w-6 h-6 text-gray-700" />
                          </button>
                        </div>

                        {/* Right Side - Content */}
                        <div className="lg:w-1/2 overflow-y-auto">
                          <div className="p-8 space-y-8">
                            
                            {/* Certificate Title */}
                            <div>
                              <h2 className="text-3xl font-light text-gray-900 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                                {certificate.name}
                              </h2>
                              <div className="flex items-center gap-3 mb-6">
                                <Shield className="w-5 h-5 text-gray-500" />
                                <span className="text-lg text-gray-700">{certificate.issuer}</span>
                              </div>
                            </div>

                            {/* Description */}
                            <div>
                              <h3 className="text-xl font-medium text-gray-900 mb-4">Description</h3>
                              <p className="text-gray-700 leading-relaxed">
                                {certificate.description}
                              </p>
                            </div>

                            {/* Skills */}
                            <div>
                              <h3 className="text-xl font-medium text-gray-900 mb-4">Skills Demonstrated</h3>
                              <div className="grid grid-cols-2 gap-3">
                                {certificate.skills.map((skill, skillIndex) => (
                                  <div key={skillIndex} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                                    <div className={`w-2 h-2 ${certificate.accentColor} rounded-full flex-shrink-0`}></div>
                                    <span className="text-sm text-gray-700">{skill}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Credential Info */}
                            <div className={`${certificate.bgColor} p-6 rounded-xl border ${certificate.borderColor}`}>
                              <h3 className="text-xl font-medium text-gray-900 mb-4">Credential Information</h3>
                              <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-gray-600">Credential ID:</span>
                                  <span className="text-sm font-mono text-gray-800">{certificate.credentialId}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-gray-600">Issued:</span>
                                  <span className="text-sm text-gray-800">{certificate.date}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-gray-600">Category:</span>
                                  <span className={`text-sm text-white px-2 py-1 ${certificate.accentColor} rounded-md`}>
                                    {certificate.category}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Navigation Info */}
                            <div className="pt-4 border-t border-gray-200">
                              <p className="text-sm text-gray-500 text-center">
                                Certificate {currentIndex + 1} of {certificates.length} • Use arrow keys or click navigation buttons
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default ElegantCertificates;