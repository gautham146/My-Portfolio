import React, { useEffect, useRef } from "react";
import { motion } from "motion/react";
import { gsap } from "gsap";

export default function Hero() {
  const nameRef = useRef(null); // Keeping refs for potential typing animation
  const titleRef = useRef(null);
  const descRef = useRef(null);

  //Find other use
  /*useEffect(() => {
    const tl = gsap.timeline({ delay: 0.5 });

    tl.to(nameRef.current, {
      text: "Gautham Girish",
      duration: 2,
      ease: "none",
    })
      .to(
        titleRef.current,
        {
          text: "Student • Developer • Creative",
          duration: 1.8,
          ease: "none",
        },
        "+=0.3",
      )
      .to(
        descRef.current,
        {
          text: "Passionate about technology, innovation, and creating meaningful digital experiences that make a difference.",
          duration: 2.5,
          ease: "none",
        },
        "+=0.2",
      );
  }, []);*/

  return (
    <motion.section
      className="min-h-screen flex flex-col items-center justify-center px-6 py-20"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <div className="max-w-4xl text-center">
        <motion.h1
          // ref={nameRef} // Keeping ref for potential typing animation
          className="text-6xl md:text-8xl mb-6 font-light"
          style={{ fontFamily: "'Playfair Display', serif" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          Portfolio
        </motion.h1>

        <motion.p
          // ref={titleRef} // Keeping ref for potential typing animation
          className="text-xl md:text-2xl mb-8 text-stone-600 font-normal italic"
          style={{ fontFamily: "'Crimson Text', serif" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          Student • Developer • Creative
        </motion.p>

        <motion.p
          // ref={descRef} // Keeping ref for potential typing animation
          className="text-lg md:text-xl max-w-2xl mx-auto text-stone-700 leading-relaxed font-normal"
          style={{ fontFamily: "'EB Garamond', serif" }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          Passionate about technology, innovation, and creating
          meaningful digital experiences that make a difference.
        </motion.p>

        <motion.div
          className="mt-12"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
        >
          <motion.button
            className="px-8 py-3 bg-stone-900 text-stone-50 rounded-full hover:bg-stone-800 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Explore My Work
          </motion.button>
        </motion.div>
      </div>
    </motion.section>
  );
}