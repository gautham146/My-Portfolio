import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const CleanSkills = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement[]>([]);

  const skillCategories = [
    {
      category: "Frontend Development",
      skills: [
        { name: 'React & Next.js', level: 95 },
        { name: 'TypeScript', level: 90 },
        { name: 'CSS & Tailwind', level: 92 },
        { name: 'JavaScript ES6+', level: 88 }
      ]
    },
    {
      category: "Design & Animation",
      skills: [
        { name: 'UI/UX Design', level: 85 },
        { name: 'GSAP Animations', level: 88 },
        { name: 'Motion Design', level: 82 },
        { name: 'Figma', level: 90 }
      ]
    },
    {
      category: "Backend & Tools",
      skills: [
        { name: 'Node.js', level: 85 },
        { name: 'Python', level: 80 },
        { name: 'Git & GitHub', level: 92 },
        { name: 'API Development', level: 75 }
      ]
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Animate skill bars on scroll
    skillsRef.current.forEach((skillCategory, categoryIndex) => {
      if (!skillCategory) return;
      
      const skillBars = skillCategory.querySelectorAll('.skill-bar');
      const skillPercentages = skillCategory.querySelectorAll('.skill-percentage');
      
      ScrollTrigger.create({
        trigger: skillCategory,
        start: "top 80%",
        onEnter: () => {
          skillBars.forEach((bar, skillIndex) => {
            const categorySkills = skillCategories[categoryIndex].skills;
            const level = categorySkills[skillIndex]?.level || 0;
            
            gsap.fromTo(bar, 
              { scaleX: 0 },
              { 
                scaleX: level / 100, 
                duration: 1.5, 
                delay: skillIndex * 0.1,
                ease: "power3.out"
              }
            );
            
            gsap.fromTo(skillPercentages[skillIndex],
              { textContent: 0 },
              {
                textContent: level,
                duration: 1.5,
                delay: skillIndex * 0.1,
                snap: { textContent: 1 },
                ease: "power3.out"
              }
            );
          });
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section id="skills" ref={sectionRef} className="min-h-screen py-32 relative">
      <div className="max-w-5xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Skills & Expertise
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto font-normal leading-relaxed"
            style={{ fontFamily: "'EB Garamond', serif" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            A curated set of technologies and disciplines that enable me to bring ideas to life.
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* Skills categories */}
        <div className="space-y-16">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.category}
              ref={(el) => el && (skillsRef.current[categoryIndex] = el)}
              className="group"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: categoryIndex * 0.2 }}
              viewport={{ once: true }}
            >
              <div className="minimal-card p-8 md:p-12">
                <h3 className="text-2xl font-light text-gray-800 mb-8 tracking-wide">
                  {category.category}
                </h3>
                
                <div className="space-y-6">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skill.name} className="group/skill">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-gray-700 font-light">{skill.name}</span>
                        <span className="text-gray-500 text-sm">
                          <span className="skill-percentage">0</span>%
                        </span>
                      </div>
                      
                      <div className="relative h-1 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="skill-bar absolute inset-y-0 left-0 bg-gray-600 rounded-full transition-all duration-300 group-hover/skill:bg-gray-800"
                          style={{ 
                            transformOrigin: 'left',
                            transform: 'scaleX(0)'
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Philosophy section */}
        <motion.div
          className="mt-24 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
        >
          <div className="max-w-3xl mx-auto">
            <p className="text-xl text-gray-600 font-light leading-relaxed italic">
              "Excellence is not a skill, it's an attitude. I believe in continuous learning, 
              thoughtful execution, and the pursuit of perfection in every detail."
            </p>
            <div className="w-12 h-px bg-gray-400 mx-auto mt-8" />
          </div>
        </motion.div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-20 left-16 w-12 h-px bg-gray-200 opacity-30" />
      <div className="absolute bottom-32 right-16 w-px h-16 bg-gray-200 opacity-30" />
    </section>
  );
};

export default CleanSkills;