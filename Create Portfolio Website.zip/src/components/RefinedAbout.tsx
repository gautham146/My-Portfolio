import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const RefinedAbout = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    const text = textRef.current;
    
    if (!section || !text) return;

    // Text reveal animation
    ScrollTrigger.create({
      trigger: section,
      start: "top 70%",
      onEnter: () => {
        gsap.fromTo(text, 
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 1.2, ease: "power3.out" }
        );
      }
    });

    // Cards stagger animation
    cardsRef.current.forEach((card, index) => {
      if (!card) return;
      
      ScrollTrigger.create({
        trigger: card,
        start: "top 85%",
        onEnter: () => {
          gsap.fromTo(card, 
            { y: 40, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.8,
              delay: index * 0.15,
              ease: "power2.out"
            }
          );
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const interests = [
    {
      title: "Design Systems",
      description: "Creating cohesive, scalable design languages that bridge the gap between design and development.",
      number: "01"
    },
    {
      title: "Interactive Media",
      description: "Exploring the boundaries of web technology through immersive and engaging digital experiences.",
      number: "02"
    },
    {
      title: "Performance",
      description: "Optimizing applications for speed and efficiency without compromising on visual quality.",
      number: "03"
    },
    {
      title: "Accessibility",
      description: "Ensuring digital experiences are inclusive and accessible to users of all abilities.",
      number: "04"
    }
  ];

  return (
    <section id="about" ref={sectionRef} className="min-h-screen py-32 relative">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            About
          </motion.h2>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
          />
        </div>

        <div className="grid lg:grid-cols-5 gap-16 items-start mb-32">
          
          {/* Main content */}
          <div className="lg:col-span-3">
            <div ref={textRef} className="space-y-8">
              <h3 className="text-3xl md:text-4xl font-light text-gray-800 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                Passionate about creating digital experiences that matter.
              </h3>
              
              <div className="space-y-6">
                <p className="text-lg text-gray-600 leading-relaxed font-normal" style={{ fontFamily: "'EB Garamond', serif" }}>
                  I'm a creative developer with a deep appreciation for clean, functional design. 
                  My approach combines technical precision with aesthetic sensibility, 
                  creating solutions that are both beautiful and purposeful.
                </p>
                
                <p className="text-lg text-gray-600 leading-relaxed font-light">
                  With expertise spanning frontend development, user experience design, 
                  and emerging web technologies, I bring ideas to life through code that 
                  prioritizes performance, accessibility, and user delight.
                </p>
              </div>

              {/* Minimal stats */}
              <div className="grid grid-cols-3 gap-8 pt-12 border-t border-gray-200">
                <div>
                  <div className="text-2xl font-light text-gray-800 mb-1">3+</div>
                  <div className="text-sm text-gray-500 uppercase tracking-wider">Years</div>
                </div>
                <div>
                  <div className="text-2xl font-light text-gray-800 mb-1">25+</div>
                  <div className="text-sm text-gray-500 uppercase tracking-wider">Projects</div>
                </div>
                <div>
                  <div className="text-2xl font-light text-gray-800 mb-1">∞</div>
                  <div className="text-sm text-gray-500 uppercase tracking-wider">Ideas</div>
                </div>
              </div>
            </div>
          </div>

          {/* Side image placeholder */}
          <div className="lg:col-span-2">
            <div className="relative">
              <div className="aspect-[3/4] bg-gray-100 rounded-sm overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-100 flex items-center justify-center">
                  <div className="text-6xl text-gray-400">👨‍💻</div>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -top-4 -left-4 w-8 h-8 border-l border-t border-gray-300" />
              <div className="absolute -bottom-4 -right-4 w-8 h-8 border-r border-b border-gray-300" />
            </div>
          </div>
        </div>

        {/* Interests grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {interests.map((interest, index) => (
            <motion.div
              key={interest.title}
              ref={(el) => el && (cardsRef.current[index] = el)}
              className="group"
              whileHover={{ y: -5 }}
              transition={{ duration: 0.3 }}
            >
              <div className="minimal-card p-8 h-full hover:shadow-lg transition-all duration-500">
                <div className="text-xs text-gray-400 mb-4 tracking-widest uppercase">
                  {interest.number}
                </div>
                <h4 className="text-xl font-light text-gray-800 mb-4">
                  {interest.title}
                </h4>
                <p className="text-gray-600 text-sm leading-relaxed font-light">
                  {interest.description}
                </p>
                
                {/* Subtle hover indicator */}
                <div className="w-0 h-px bg-gray-400 group-hover:w-full transition-all duration-500 mt-6" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-40 right-20 w-px h-20 bg-gray-200 opacity-30" />
      <div className="absolute bottom-40 left-20 w-16 h-px bg-gray-200 opacity-30" />
    </section>
  );
};

export default RefinedAbout;