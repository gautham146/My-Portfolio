import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';

export default function IntroAnimation({ onComplete }) {
  const helloRef = useRef(null);
  const nameRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline({
      onComplete: () => {
        setTimeout(onComplete, 200);
      }
    });

    // Initial setup
    gsap.set([helloRef.current, nameRef.current], { opacity: 0 });

    // Animation sequence - Much faster
    tl.to(helloRef.current, {
      opacity: 1,
      duration: 0.4,
      ease: "power2.out"
    })
    .to(helloRef.current, {
      text: "hello, I am",
      duration: 0.6,
      ease: "none"
    }, "-=0.2")
    .to(nameRef.current, {
      opacity: 1,
      duration: 0.3,
      ease: "power2.out"
    }, "+=0.1")
    .to(nameRef.current, {
      text: "gautham girish",
      duration: 0.8,
      ease: "none"
    }, "-=0.2")
    .to(nameRef.current, {
      text: "Gautham Girish",
      duration: 0.4,
      ease: "power2.inOut",
      fontSize: "4rem",
      fontWeight: "600"
    }, "+=0.2")
    .to(containerRef.current, {
      backgroundColor: "#fafaf9",
      color: "#1c1917",
      duration: 0.6,
      ease: "power2.inOut"
    }, "+=0.1")
    .to([helloRef.current, nameRef.current], {
      opacity: 0,
      y: -50,
      duration: 0.4,
      ease: "power2.in"
    }, "+=0.2");

  }, [onComplete]);

  return (
    <motion.div
      ref={containerRef}
      className="fixed inset-0 flex flex-col items-center justify-center bg-black text-white z-50"
      style={{ fontFamily: "'Poppins', sans-serif" }}
    >
      <div 
        ref={helloRef}
        className="text-2xl mb-4 font-medium"
      />
      <div 
        ref={nameRef}
        className="text-3xl font-semibold"
      />
    </motion.div>
  );
}