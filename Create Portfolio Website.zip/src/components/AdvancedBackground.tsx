import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';

const AdvancedBackground = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const orbs = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Mouse following effect
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = e.clientX;
      mouseRef.current.y = e.clientY;

      // Animate orbs to follow mouse with different speeds
      orbs.current.forEach((orb, index) => {
        const speed = (index + 1) * 0.02;
        const x = (mouseRef.current.x - window.innerWidth / 2) * speed;
        const y = (mouseRef.current.y - window.innerHeight / 2) * speed;
        
        gsap.to(orb, {
          x: x,
          y: y,
          duration: 3 - index * 0.5,
          ease: "power2.out"
        });
      });
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Floating animation for mesh gradients
    const meshElements = container.querySelectorAll('.mesh-orb');
    meshElements.forEach((element, index) => {
      gsap.to(element, {
        y: "random(-50, 50)",
        x: "random(-30, 30)",
        scale: "random(0.8, 1.2)",
        rotation: "random(-180, 180)",
        duration: "random(8, 15)",
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        delay: index * 0.5
      });
    });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Animated mesh gradient background */}
      <div className="absolute inset-0 bg-gradient-mesh opacity-60" />
      
      {/* Floating mesh orbs */}
      {Array.from({ length: 6 }, (_, i) => (
        <div
          key={i}
          className="mesh-orb absolute w-96 h-96 rounded-full opacity-20"
          style={{
            background: `radial-gradient(circle, ${
              ['rgba(120, 119, 198, 0.6)', 'rgba(255, 183, 77, 0.5)', 'rgba(255, 77, 77, 0.5)', 
               'rgba(120, 198, 121, 0.5)', 'rgba(198, 120, 221, 0.5)', 'rgba(77, 196, 255, 0.5)'][i]
            } 0%, transparent 70%)`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            filter: 'blur(40px)',
          }}
        />
      ))}

      {/* Interactive mouse-following orbs */}
      {Array.from({ length: 3 }, (_, i) => (
        <div
          key={`mouse-orb-${i}`}
          ref={(el) => el && (orbs.current[i] = el)}
          className="absolute w-32 h-32 rounded-full pointer-events-none opacity-30"
          style={{
            background: `radial-gradient(circle, ${
              ['rgba(120, 119, 198, 0.8)', 'rgba(255, 183, 77, 0.6)', 'rgba(77, 196, 255, 0.7)'][i]
            } 0%, transparent 70%)`,
            filter: 'blur(20px)',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        />
      ))}

      {/* Geometric patterns */}
      <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(120, 119, 198, 0.3)" strokeWidth="1"/>
          </pattern>
          <linearGradient id="gridGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(120, 119, 198, 0.5)" />
            <stop offset="100%" stopColor="rgba(255, 183, 77, 0.3)" />
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        
        {/* Animated lines */}
        {Array.from({ length: 4 }, (_, i) => (
          <motion.line
            key={i}
            x1={i * 300}
            y1="0"
            x2={i * 300 + 100}
            y2="100%"
            stroke="url(#gridGrad)"
            strokeWidth="2"
            opacity="0.4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{
              duration: 3,
              delay: i * 0.5,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }}
          />
        ))}
      </svg>

      {/* Noise texture overlay */}
      <div 
        className="absolute inset-0 opacity-10 mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  );
};

export default AdvancedBackground;