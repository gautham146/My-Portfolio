import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Users, Award, BookOpen, PenTool, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

gsap.registerPlugin(ScrollTrigger);

interface ExpandableExtracurricularsProps {
  onModalChange?: (isOpen: boolean) => void;
}

const ExpandableExtracurriculars = ({ onModalChange }: ExpandableExtracurricularsProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);
  const [selectedActivity, setSelectedActivity] = useState<number | null>(null);
  const [modalImageIndex, setModalImageIndex] = useState<number>(0);

  const activities = [
    {
      title: "Computer Science Club",
      role: "Vice President",
      description: "Leading a team of 50+ students in organizing coding competitions, workshops, and tech talks.",
      fullDescription: "As Vice President of the Computer Science Club, I've spearheaded the transformation of our organization into one of the most active tech communities on campus. My leadership has involved strategic planning, team coordination, and creating an inclusive environment where students from all backgrounds can explore technology. We've organized major hackathons, guest lectures from industry professionals, and collaborative coding sessions that have significantly enhanced the learning experience for our members.",
      period: "2023 - Present",
      icon: Users,
      metrics: ["50+ Members", "15+ Colleges", "12 Events"],
      achievements: [
        "Increased membership by 300% in one year",
        "Organized the largest campus hackathon with 200+ participants", 
        "Established partnerships with 5 major tech companies",
        "Created mentorship program connecting students with industry professionals"
      ],
      // PASTE YOUR IMAGE URLS HERE - Add multiple images for a carousel in the expanded modal!
      // Upload to ImgBB (https://imgbb.com/) and paste the "Direct link" 
      // To add more images: Just add more URLs to the array, separated by commas
      // Example: images: ["url1.jpg", "url2.jpg", "url3.jpg", "url4.jpg"]
      images: [
        "https://images.unsplash.com/photo-1753613648137-602c669cbe07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMHNjaWVuY2UlMjBjb2RpbmclMjBzdHVkZW50c3xlbnwxfHx8fDE3NTkwMDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1531482615713-2afd69097998?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxjb21wdXRlciUyMHNjaWVuY2UlMjBjb2RpbmclMjBzdHVkZW50c3xlbnwxfHx8fDE3NTkwMDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxjb21wdXRlciUyMHNjaWVuY2UlMjBjb2RpbmclMjBzdHVkZW50c3xlbnwxfHx8fDE3NTkwMDYwMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    },
    {
      title: "Debate Society",
      role: "Active Member",
      description: "Participated in inter-college debate competitions, developing critical thinking and public speaking skills.",
      fullDescription: "My involvement in the Debate Society has been instrumental in developing my communication and analytical skills. Through rigorous training sessions and competitive debates, I've learned to articulate complex ideas clearly, think critically under pressure, and defend positions with well-researched arguments. This experience has not only improved my public speaking abilities but also enhanced my capacity to understand multiple perspectives on challenging topics.",
      period: "2022 - Present",
      icon: Award,
      metrics: ["8 Competitions", "3 Awards", "2 Years"],
      achievements: [
        "Won 3 inter-college debate competitions",
        "Ranked in top 10 at national debate championship",
        "Trained 15+ new members in debate techniques",
        "Developed critical thinking workshops for fellow students"
      ],
      // Add your images here - these will appear in the modal carousel
      images: [
        "https://images.unsplash.com/photo-1709377418835-304afc0e064a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWJhdGUlMjBjb21wZXRpdGlvbiUyMHB1YmxpYyUyMHNwZWFraW5nfGVufDF8fHx8MTc1OTAwNjAzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxkZWJhdGUlMjBjb21wZXRpdGlvbiUyMHB1YmxpYyUyMHNwZWFraW5nfGVufDF8fHx8MTc1OTAwNjAzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1560523159-4a8b7bc8c01f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxkZWJhdGUlMjBjb21wZXRpdGlvbiUyMHB1YmxpYyUyMHNwZWFraW5nfGVufDF8fHx8MTc1OTAwNjAzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    },
    {
      title: "Community Service Initiative",
      role: "Volunteer Coordinator",
      description: "Organized digital literacy programs for underprivileged communities, teaching basic computer skills.",
      fullDescription: "Coordinating community service initiatives has been one of my most rewarding experiences. I've designed and implemented comprehensive digital literacy programs that bridge the technology gap in underserved communities. My role involved curriculum development, volunteer training, resource management, and direct teaching. The impact has been profound - seeing individuals gain confidence with technology and open new opportunities for themselves reinforces my belief in technology's power to create positive social change.",
      period: "2022 - 2024",
      icon: BookOpen,
      metrics: ["100+ Students", "5 Programs", "24 Months"],
      achievements: [
        "Established 3 permanent computer labs in community centers",
        "Trained 25 volunteer instructors",
        "Achieved 95% course completion rate",
        "Connected 50+ participants to employment opportunities"
      ],
      // Add your images here - these will appear in the modal carousel
      images: [
        "https://images.unsplash.com/photo-1743793174491-bcbdf1882ad5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBzZXJ2aWNlJTIwdGVhY2hpbmclMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1OTAwNjA0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxjb21tdW5pdHklMjBzZXJ2aWNlJTIwdGVhY2hpbmclMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1OTAwNjA0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1559027615-cd4628902d4a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxjb21tdW5pdHklMjBzZXJ2aWNlJTIwdGVhY2hpbmclMjB2b2x1bnRlZXJzfGVufDF8fHx8MTc1OTAwNjA0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    },
    {
      title: "University Tech Magazine",
      role: "Contributing Writer",
      description: "Writing articles about emerging technologies, startup culture, and the intersection of tech and society.",
      fullDescription: "Contributing to the University Tech Magazine has allowed me to explore the intersection of technology and society through written expression. My articles cover emerging technologies, startup ecosystems, and the societal implications of digital transformation. This role has sharpened my research skills, taught me to translate complex technical concepts for diverse audiences, and provided a platform to voice perspectives on the future of technology. Each piece requires extensive research, interviews with industry professionals, and careful consideration of multiple viewpoints.",
      period: "2023 - Present", 
      icon: PenTool,
      metrics: ["15 Articles", "10K+ Readers", "Monthly"],
      achievements: [
        "Published cover story on AI ethics reaching 50K+ readers",
        "Interviewed 20+ industry leaders and startup founders",
        "Created multimedia content strategy increasing engagement by 200%",
        "Launched podcast series discussing tech trends"
      ],
      // Add your images here - these will appear in the modal carousel
      images: [
        "https://images.unsplash.com/photo-1663025292954-dd09983bd945?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3cml0aW5nJTIwbWFnYXppbmUlMjBqb3VybmFsaXNtJTIwdGVjaHxlbnwxfHx8fDE3NTkwMDYwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1455390582262-044cdead277a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHx3cml0aW5nJTIwbWFnYXppbmUlMjBqb3VybmFsaXNtJTIwdGVjaHxlbnwxfHx8fDE3NTkwMDYwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHx3cml0aW5nJTIwbWFnYXppbmUlMjBqb3VybmFsaXNtJTIwdGVjaHxlbnwxfHx8fDE3NTkwMDYwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      ]
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Cards stagger animation
    cardsRef.current.forEach((card, index) => {
      if (!card) return;
      
      ScrollTrigger.create({
        trigger: card,
        start: "top 85%",
        onEnter: () => {
          gsap.fromTo(card, 
            { y: 40, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.8,
              delay: index * 0.15,
              ease: "power2.out"
            }
          );
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  // Auto-rotate images in modal every 4 seconds
  useEffect(() => {
    if (selectedActivity === null) return;
    
    const activity = activities[selectedActivity];
    if (!activity || activity.images.length <= 1) return;

    const interval = setInterval(() => {
      setModalImageIndex(prev => (prev + 1) % activity.images.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [selectedActivity, activities]);

  const handleActivityClick = (index: number) => {
    const willBeOpen = selectedActivity !== index;
    setSelectedActivity(willBeOpen ? index : null);
    setModalImageIndex(0); // Reset to first image when opening modal
    
    // Notify parent component about modal state change
    if (onModalChange) {
      onModalChange(willBeOpen);
    }
  };

  const closeExpanded = () => {
    setSelectedActivity(null);
    
    // Notify parent that modal is closed
    if (onModalChange) {
      onModalChange(false);
    }
  };

  return (
    <section id="extracurriculars" ref={sectionRef} className="py-20 md:py-32 relative bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 md:px-6">
        
        {/* Section header */}
        <div className="text-center mb-16 md:mb-24">
          <motion.h2
            className="text-4xl md:text-5xl lg:text-6xl font-light text-gray-900 mb-6 md:mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Leadership & Impact
          </motion.h2>
          <motion.p
            className="text-base md:text-lg text-gray-600 max-w-2xl mx-auto font-light leading-relaxed px-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Click on any card to explore my leadership journey and community impact in detail.
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-6 md:mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* Activities grid */}
        <div className="grid sm:grid-cols-2 gap-6 md:gap-8 mb-12">
          {activities.map((activity, index) => (
            <motion.div
              key={activity.title}
              ref={(el) => el && (cardsRef.current[index] = el)}
              className="group cursor-pointer"
              onClick={() => handleActivityClick(index)}
              whileHover={{ y: -5 }}
              transition={{ duration: 0.3 }}
            >
              <div className="bg-white rounded-2xl overflow-hidden border border-gray-200 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-xl transition-all duration-500">
                
                {/* Static Image Preview - Mobile Optimized */}
                <div className="h-40 md:h-48 overflow-hidden relative bg-gray-50">
                  <ImageWithFallback
                    src={activity.images[0]}
                    alt={activity.title}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Icon indicator */}
                  <div className="absolute top-3 right-3 md:top-4 md:right-4 w-8 h-8 md:w-10 md:h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:bg-gray-800 transition-colors duration-300">
                    <activity.icon className="w-4 h-4 md:w-5 md:h-5 text-gray-700 group-hover:text-white transition-colors duration-300" />
                  </div>
                </div>

                {/* Card Info */}
                <div className="p-4 md:p-6">
                  <h3 className="text-lg md:text-xl text-gray-900 mb-2 group-hover:text-gray-700 transition-colors duration-300" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {activity.title}
                  </h3>
                  <div className="flex items-center gap-2 text-xs md:text-sm text-gray-500 font-light mb-3">
                    <span>{activity.role}</span>
                    <div className="w-1 h-1 bg-gray-300 rounded-full" />
                    <span>{activity.period}</span>
                  </div>
                  <p className="text-xs md:text-sm text-gray-600 font-light leading-relaxed line-clamp-2">
                    {activity.description}
                  </p>
                </div>
                
                {/* Bottom accent */}
                <div className="h-1 bg-gray-800 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Fullscreen Modal */}
        <AnimatePresence>
          {selectedActivity !== null && (
            <motion.div
              className="fixed inset-0 z-[100] flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Backdrop */}
              <motion.div
                className="absolute inset-0 bg-black"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.8 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                onClick={closeExpanded}
              />

              {/* Modal Content */}
              <motion.div
                className="relative w-full h-full bg-white overflow-hidden"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                onClick={(e) => e.stopPropagation()}
              >
                {(() => {
                  const activity = activities[selectedActivity];
                  const IconComponent = activity.icon;
                  
                  return (
                    <>
                      {/* Header - Mobile Optimized */}
                      <div className="absolute top-0 left-0 right-0 z-20 bg-white/95 backdrop-blur-md border-b border-gray-200">
                        <div className="flex items-center justify-between px-4 md:px-8 py-4 md:py-6">
                          <div className="flex items-center gap-3 md:gap-4 flex-1 min-w-0">
                            <div className="w-8 h-8 md:w-10 md:h-10 bg-gray-800 rounded-xl flex items-center justify-center flex-shrink-0">
                              <IconComponent className="w-4 h-4 md:w-5 md:h-5 text-white" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <h1 className="text-lg md:text-2xl font-semibold text-gray-900 truncate" style={{ fontFamily: "'Playfair Display', serif" }}>
                                {activity.title}
                              </h1>
                              <p className="text-xs md:text-sm text-gray-600 truncate">{activity.role} • {activity.period}</p>
                            </div>
                          </div>
                          <button
                            onClick={closeExpanded}
                            className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center hover:bg-gray-100 rounded-xl transition-colors duration-200 flex-shrink-0 ml-2"
                            aria-label="Close modal"
                          >
                            <X className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
                          </button>
                        </div>
                      </div>

                      {/* Main Content - Mobile Optimized with proper scrolling */}
                      <div className="pt-16 md:pt-24 h-full overflow-y-auto overscroll-contain"
                        style={{ WebkitOverflowScrolling: 'touch' }}
                      >
                        
                        {/* Image Carousel - Mobile Optimized */}
                        <div className="w-full h-[250px] md:h-[400px] lg:h-[500px] relative overflow-hidden px-4 md:px-12 pt-4 md:pt-6 bg-gray-50">
                          {/* Carousel Images */}
                          <div className="relative w-full h-full">
                            {activity.images.map((image, imgIndex) => (
                              <div
                                key={imgIndex}
                                className="absolute inset-0 transition-opacity duration-1000"
                                style={{
                                  opacity: modalImageIndex === imgIndex ? 1 : 0,
                                  pointerEvents: modalImageIndex === imgIndex ? 'auto' : 'none'
                                }}
                              >
                                <ImageWithFallback
                                  src={image}
                                  alt={`${activity.title} - Image ${imgIndex + 1}`}
                                  className="w-full h-full object-contain rounded-lg md:rounded-xl"
                                />
                              </div>
                            ))}
                          </div>

                          {/* Carousel Controls - Only show if multiple images */}
                          {activity.images.length > 1 && (
                            <>
                              {/* Navigation Arrows */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setModalImageIndex(prev => 
                                    prev === 0 ? activity.images.length - 1 : prev - 1
                                  );
                                }}
                                className="absolute left-2 md:left-16 top-1/2 transform -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110 z-10"
                                aria-label="Previous image"
                              >
                                <svg className="w-5 h-5 md:w-6 md:h-6 text-gray-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                </svg>
                              </button>
                              
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setModalImageIndex(prev => 
                                    prev === activity.images.length - 1 ? 0 : prev + 1
                                  );
                                }}
                                className="absolute right-2 md:right-16 top-1/2 transform -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110 z-10"
                                aria-label="Next image"
                              >
                                <svg className="w-5 h-5 md:w-6 md:h-6 text-gray-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                              </button>

                              {/* Carousel Indicators */}
                              <div className="absolute bottom-4 md:bottom-8 left-1/2 transform -translate-x-1/2 flex gap-1.5 md:gap-2 z-10">
                                {activity.images.map((_, imgIndex) => (
                                  <button
                                    key={imgIndex}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setModalImageIndex(imgIndex);
                                    }}
                                    className={`h-1.5 md:h-2 rounded-full transition-all duration-500 ${
                                      modalImageIndex === imgIndex
                                        ? 'bg-gray-800 w-6 md:w-8'
                                        : 'bg-gray-400 w-1.5 md:w-2 hover:bg-gray-600'
                                    }`}
                                    aria-label={`Go to image ${imgIndex + 1}`}
                                  />
                                ))}
                              </div>

                              {/* Image Counter */}
                              <div className="absolute top-4 md:top-10 right-4 md:right-16 bg-black/60 text-white px-3 py-1.5 md:px-4 md:py-2 rounded-full text-xs md:text-sm backdrop-blur-sm">
                                {modalImageIndex + 1} / {activity.images.length}
                              </div>
                            </>
                          )}
                        </div>

                        {/* Content Below Image - Mobile Optimized */}
                        <div className="max-w-6xl mx-auto px-4 md:px-8 lg:px-12 py-6 md:py-8">
                          
                          {/* Overview */}
                          <div className="mb-5 md:mb-6">
                            <h2 className="text-lg md:text-xl font-light text-gray-900 mb-2 md:mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                              Overview
                            </h2>
                            <p className="text-sm md:text-base text-gray-700 leading-relaxed font-light">
                              {activity.fullDescription}
                            </p>
                          </div>

                          {/* Key Achievements and Skills Side by Side */}
                          <div className="grid md:grid-cols-2 gap-6 md:gap-8 pb-6 md:pb-8">
                            
                            {/* Key Achievements */}
                            <div>
                              <h3 className="text-base md:text-lg font-light text-gray-900 mb-2 md:mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                                Key Achievements
                              </h3>
                              <div className="space-y-1.5 md:space-y-2">
                                {activity.achievements.map((achievement, achIndex) => (
                                  <div key={achIndex} className="flex items-start gap-2 text-xs md:text-sm">
                                    <div className="w-1.5 h-1.5 rounded-full bg-gray-800 mt-1.5 flex-shrink-0"></div>
                                    <span className="text-gray-700 leading-relaxed">
                                      {achievement}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Skills & Learning */}
                            <div>
                              <h3 className="text-base md:text-lg font-light text-gray-900 mb-2 md:mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                                Skills & Learning
                              </h3>
                              <div className="space-y-2 md:space-y-3">
                                <div>
                                  <h4 className="font-medium text-gray-800 mb-1 md:mb-1.5 text-xs md:text-sm">Leadership Skills</h4>
                                  <ul className="space-y-0.5 text-xs md:text-sm text-gray-600">
                                    <li>• Team Management</li>
                                    <li>• Strategic Planning</li>
                                  </ul>
                                </div>
                                <div>
                                  <h4 className="font-medium text-gray-800 mb-1 md:mb-1.5 text-xs md:text-sm">Technical Skills</h4>
                                  <ul className="space-y-0.5 text-xs md:text-sm text-gray-600">
                                    <li>• Event Organization</li>
                                    <li>• Public Speaking</li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Philosophy section */}
        <motion.div
          className="mt-16 md:mt-24 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="max-w-3xl mx-auto px-4">
            <p className="text-base md:text-xl text-gray-600 font-light leading-relaxed italic">
              "Leadership isn't about being in charge. It's about taking care of those in your charge 
              and creating opportunities for others to grow."
            </p>
            <div className="w-12 h-px bg-gray-400 mx-auto mt-6 md:mt-8" />
          </div>
        </motion.div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-32 left-16 w-16 h-px bg-gray-200 opacity-40" />
      <div className="absolute bottom-24 right-16 w-px h-20 bg-gray-200 opacity-40" />
    </section>
  );
};

export default ExpandableExtracurriculars;
