import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Building2, GraduationCap, Users, Download, Mail, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const RefinedJobs = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<HTMLDivElement[]>([]);

  const experiences = [
    {
      company: "TechStart Solutions",
      position: "Frontend Developer Intern",
      description: "Developed responsive web applications using React and TypeScript. Collaborated with design teams to implement pixel-perfect UI components and improved application performance by 40%.",
      period: "Jun 2024 - Aug 2024",
      achievements: ["Built 5+ reusable React components", "Reduced bundle size by 25%", "Implemented dark mode feature"],
      icon: Building2,
      type: "Internship",
      color: "bg-blue-50 border-blue-200",
      iconColor: "text-blue-600"
    },
    {
      company: "Digital Innovation Lab",
      position: "Research Assistant",
      description: "Conducted research on human-computer interaction and accessibility in web applications. Contributed to academic papers and presented findings at student conferences.",
      period: "Jan 2024 - May 2024",
      achievements: ["Co-authored 2 research papers", "Developed accessibility testing framework", "Presented at 3 conferences"],
      icon: GraduationCap,
      type: "Research",
      color: "bg-purple-50 border-purple-200",
      iconColor: "text-purple-600"
    },
    {
      company: "Local Community Center",
      position: "Programming Instructor",
      description: "Taught basic programming concepts to high school students and adults. Designed curriculum for beginner-friendly coding workshops covering HTML, CSS, and JavaScript fundamentals.",
      period: "Sep 2023 - Dec 2023",
      achievements: ["Taught 50+ students", "Developed interactive curriculum", "95% student satisfaction rate"],
      icon: Users,
      type: "Teaching",
      color: "bg-green-50 border-green-200",
      iconColor: "text-green-600"
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Animate cards on scroll
    cardRefs.current.forEach((card, index) => {
      if (!card) return;
      
      ScrollTrigger.create({
        trigger: card,
        start: "top 85%",
        onEnter: () => {
          gsap.fromTo(card, 
            { y: 80, opacity: 0, scale: 0.8 },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              duration: 1.2,
              delay: index * 0.2,
              ease: "power3.out"
            }
          );
        }
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section id="work" ref={sectionRef} className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section header */}
        <div className="text-center mb-24">
          <motion.h2
            className="text-5xl md:text-6xl font-light text-gray-900 mb-8 tracking-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            Professional Journey
          </motion.h2>
          <motion.p
            className="text-lg text-gray-600 max-w-2xl mx-auto font-light leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
          >
            Each experience has shaped my understanding of technology's potential to create meaningful impact.
          </motion.p>
          <motion.div
            className="w-20 h-px bg-gray-400 mx-auto mt-8"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
          />
        </div>

        {/* Experience cards in masonry-style layout */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              ref={(el) => el && (cardRefs.current[index] = el)}
              className="break-inside-avoid mb-8"
            >
              <motion.div
                className={`${exp.color} p-8 rounded-2xl border-2 group hover:shadow-2xl hover:scale-105 transition-all duration-500 relative overflow-hidden cursor-pointer`}
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {/* Floating background elements */}
                <div className="absolute top-4 right-4 w-16 h-16 bg-white/30 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute bottom-4 left-4 w-8 h-8 bg-white/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                
                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm group-hover:shadow-md transition-all duration-300`}>
                      <exp.icon className={`w-6 h-6 ${exp.iconColor} transition-all duration-300`} />
                    </div>
                    <div>
                      <span className="text-xs text-gray-600 bg-white/60 px-3 py-1 rounded-full uppercase tracking-wider font-medium">
                        {exp.type}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="relative mb-6">
                  <h3 className="text-xl font-medium text-gray-900 mb-2 group-hover:text-gray-800 transition-colors duration-300">
                    {exp.position}
                  </h3>
                  <p className="text-lg text-gray-700 font-light">
                    {exp.company}
                  </p>
                  <p className="text-sm text-gray-600 mt-2 font-light">
                    {exp.period}
                  </p>
                </div>

                <p className="text-gray-700 leading-relaxed font-light mb-8">
                  {exp.description}
                </p>

                {/* Achievements */}
                <div className="space-y-3 mb-6">
                  <h4 className="text-sm text-gray-800 uppercase tracking-wider font-medium">Key Achievements</h4>
                  {exp.achievements.map((achievement, achIndex) => (
                    <motion.div
                      key={achIndex}
                      className="flex items-start gap-3"
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.2 + achIndex * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <div className="w-1.5 h-1.5 bg-gray-600 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-gray-700 text-sm font-light leading-relaxed">
                        {achievement}
                      </span>
                    </motion.div>
                  ))}
                </div>

                {/* Learn more indicator */}
                <div className="flex items-center gap-2 text-gray-600 group-hover:text-gray-800 transition-colors duration-300">
                  <span className="text-sm font-light">Explore details</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                </div>

                {/* Interactive bottom border */}
                <div className="absolute bottom-0 left-0 w-0 h-1 bg-gradient-to-r from-gray-600 to-gray-800 group-hover:w-full transition-all duration-700 ease-out rounded-full" />
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Call to action */}
        <motion.div
          className="mt-24 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="max-w-3xl mx-auto mb-12">
            <p className="text-xl text-gray-600 font-light leading-relaxed mb-8">
              Ready to bring my passion for technology and proven track record of success to new challenges. 
              Let's build something amazing together.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <motion.button
              className="group flex items-center gap-3 px-8 py-4 bg-gray-900 text-white text-sm tracking-wide uppercase font-light rounded-lg transition-all duration-300 hover:bg-gray-800"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform duration-300" />
              <span>Download Resume</span>
            </motion.button>
            
            <motion.button
              className="group flex items-center gap-3 px-8 py-4 border border-gray-300 text-gray-700 text-sm tracking-wide uppercase font-light rounded-lg transition-all duration-300 hover:border-gray-600 hover:text-gray-900"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Mail className="w-4 h-4 group-hover:translate-x-0.5 transition-transform duration-300" />
              <span>Get In Touch</span>
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Background decorations */}
      <div className="absolute top-20 left-16 w-12 h-px bg-gray-200 opacity-30" />
      <div className="absolute bottom-32 right-16 w-px h-16 bg-gray-200 opacity-30" />
    </section>
  );
};

export default RefinedJobs;