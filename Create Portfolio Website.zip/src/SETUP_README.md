# Portfolio Setup Guide

Welcome to your portfolio! This guide will help you customize and deploy your website.

## 📋 Quick Start Checklist

Follow this checklist to set up your portfolio:

- [ ] **Personal Information** - Update your name and details
- [ ] **Images** - Add your photos
- [ ] **Contact Links** - Set up email and social media
- [ ] **Content** - Update your projects, skills, and achievements
- [ ] **Deploy** - Publish your portfolio online

---

## 🎯 Step-by-Step Setup

### 1. Update Personal Information

**Files to edit:**
- `/components/MinimalistHero.tsx` - Your name and tagline
- `/components/RefinedContact.tsx` - Footer copyright

**In MinimalistHero.tsx** (around line 100-106):
```tsx
<h1 className="..." style={{ fontFamily: "'Playfair Display', serif" }}>
  Your First Name  {/* Change this */}
</h1>
<h1 className="..." style={{ fontFamily: "'Playfair Display', serif" }}>
  Your Last Name   {/* Change this */}
</h1>
```

**Update your tagline** (around line 118):
```tsx
<h2 className="...">
  Your Title • Your Role • Your Passion  {/* Change this */}
</h2>
```

**Update description** (around line 130-134):
```tsx
<p className="...">
  Your personal description here. Write about yourself,
  your passions, and what drives you.
</p>
```

---

### 2. Add Your Images

See **[IMAGE_GUIDE.md](IMAGE_GUIDE.md)** for detailed instructions.

**Quick summary:**
- **About section photo**: 1200x1400px (portrait)
- **Leadership photos**: 1920x1080px (landscape) - See **[LEADERSHIP_IMAGE_GUIDE.md](LEADERSHIP_IMAGE_GUIDE.md)** for detailed preparation instructions

**⚠️ Important:** You must upload images to [Imgur](https://imgur.com/upload) or another hosting service and use the URL:
```tsx
const aboutImage = "https://i.imgur.com/abc123.jpg";
```

---

### 3. Setup Contact Information

See **[CONTACT_SETUP_GUIDE.md](CONTACT_SETUP_GUIDE.md)** for detailed instructions.

**Quick summary:**
1. Open `/components/RefinedContact.tsx`
2. Update the `contactMethods` array with your:
   - Email address
   - Location
   - GitHub username
   - LinkedIn profile
3. Set up form backend (recommended: FormSubmit - free and easy)

---

### 4. Update About Section

**File:** `/components/AnimatedAbout.tsx`

Update the text variables (around line 10-13):
```tsx
const subtitle1Text = "Your compelling headline here.";
const subtitle2Text = "Your expertise description.";
const paragraph1Text = "Tell your story...";
const paragraph2Text = "Share your vision...";
```

---

### 5. Update Leadership & Impact Section

**File:** `/components/ExpandableExtracurriculars.tsx`

Update the `activities` array (starting around line 15) with your actual experiences:

```tsx
{
  title: "Your Organization/Role",
  role: "Your Position",
  description: "Brief description...",
  fullDescription: "Detailed description of your role and impact...",
  period: "2023 - Present",
  icon: Users,  // Choose: Users, Award, BookOpen, PenTool
  metrics: ["50+ Members", "15+ Events", "12 Projects"],
  achievements: [
    "Your first achievement",
    "Your second achievement",
    "Your third achievement",
    "Your fourth achievement"
  ],
  image: "/your-image.jpg"  // Add your image
}
```

**Note:** The metrics are shown on the preview cards, but not in the expanded view.

---

### 6. Update Skills Section

**File:** `/components/HorizontalSkills.tsx`

Update the skills arrays with your actual skills:

```tsx
const technicalSkills = [
  { name: "Your Skill 1", level: 90 },
  { name: "Your Skill 2", level: 85 },
  // ... add more
];

const softSkills = [
  "Your Soft Skill 1",
  "Your Soft Skill 2",
  // ... add more
];
```

---

### 7. Update Certificates Section

**File:** `/components/SimpleCertificates.tsx`

Update the `certificates` array with your actual certifications and images:

```tsx
const certificates = [
  {
    id: 1,
    title: "Your Certification Name",
    issuer: "Issuing Organization",
    date: "January 2025",
    image: "/cert-preview-1.jpg",           // Preview thumbnail
    certificateImage: "/certificate-1.jpg", // Full certificate image (portrait)
    description: "Brief description of this certification"
  },
  {
    id: 2,
    title: "Another Certification",
    issuer: "Organization Name",
    date: "December 2024",
    image: "/cert-preview-2.jpg",
    certificateImage: "/certificate-2.jpg",
    description: "Brief description"
  }
];
```

**To add certificate images:**
1. Scan or screenshot your certificates (portrait orientation)
2. Place them in the `/public` folder
3. Update the `certificateImage` path to match your filename
4. Click on any certificate to view the full image in a modal

See [IMAGE_GUIDE.md](IMAGE_GUIDE.md) for detailed image specifications.

---

### 8. Update Medium Blogs

**File:** `/components/MediumBlogs.tsx`

Update the `blogs` array with your articles (shows 2 posts):

```tsx
const blogs = [
  {
    title: "Your Article Title",
    excerpt: "Brief description of your article...",
    date: "Jan 15, 2025",
    readTime: "5 min read",
    views: "2.4K",
    link: "https://medium.com/@yourusername/article-slug"
  },
  {
    title: "Your Second Article",
    excerpt: "Another description...",
    date: "Dec 28, 2024",
    readTime: "8 min read",
    views: "1.8K",
    link: "https://medium.com/@yourusername/second-article"
  }
];
```

If you don't have Medium articles, you can remove this section from `App.tsx` or replace with a different content section.

---

### 9. Update Navigation

**File:** `/components/AdvancedNavigation.tsx`

The navigation automatically links to sections using IDs. Current sections:
- Hero (`#hero`)
- About (`#about`)
- Leadership & Impact (`#extracurriculars`)
- Certifications (`#certifications`)
- Skills (`#skills`)
- Blogs (`#blogs`)
- Contact (`#contact`)

To add/remove sections:
1. Edit the `navItems` array in AdvancedNavigation.tsx
2. Add/remove corresponding components in App.tsx
3. Ensure section IDs match navigation hrefs

---

## 🎨 Customization Options

### Change Color Scheme

Currently using grayscale/minimalist theme. To customize:

**File:** `/styles/globals.css`

Update color variables in `:root` section (around line 5):
```css
:root {
  --primary: #030213;  /* Main dark color */
  --accent: #e9ebef;   /* Light accent */
  /* ... more colors */
}
```

### Change Fonts

Currently using vintage serif fonts:
- **Playfair Display** - Headings
- **Crimson Text** - Subheadings  
- **EB Garamond** - Body text

To change fonts, edit `/App.tsx` (around line 25) and update the Google Fonts link.

### Adjust Animations

Most animations use GSAP and Motion (Framer Motion). To adjust:
- **Speed:** Change `duration` values in motion components
- **Delay:** Adjust `delay` values
- **Disable:** Remove `initial`, `animate`, `transition` props

---

## 🚀 Deployment

### Option 1: Netlify (Recommended)

1. Push your code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "New site from Git"
4. Connect your GitHub repository
5. Deploy!

**Build settings:**
- Build command: `npm run build`
- Publish directory: `dist`

### Option 2: Vercel

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Deploy!

### Option 3: GitHub Pages

1. In your repository settings, enable GitHub Pages
2. Select the branch to deploy from
3. Your site will be live at `https://yourusername.github.io/repository-name`

---

## 📱 Testing Checklist

Before deploying, test:

### Desktop
- [ ] All sections load properly
- [ ] Navigation works smoothly
- [ ] Images display correctly
- [ ] Animations are smooth
- [ ] Contact links work
- [ ] Form submission works
- [ ] No console errors

### Mobile
- [ ] Responsive layout works
- [ ] Touch interactions work
- [ ] Navigation menu works
- [ ] Forms are usable
- [ ] Images load and fit properly
- [ ] Text is readable

### Performance
- [ ] Images are optimized (under 500KB each)
- [ ] Page loads in under 3 seconds
- [ ] Smooth scrolling on all devices
- [ ] No layout shifts

---

## 🛠 Troubleshooting

### Images not showing
- Check file paths are correct
- Ensure images are in `/public` folder
- Verify file extensions match (case-sensitive)

### Animations not working
- Check browser console for errors
- Ensure GSAP is properly imported
- Try refreshing the page

### Contact form not working
- See CONTACT_SETUP_GUIDE.md
- Check FormSubmit email is confirmed
- Verify form action URL is correct

### Navigation not smooth
- Ensure section IDs match navigation hrefs
- Check for JavaScript errors in console

---

## 📚 Additional Resources

- **[IMAGE_GUIDE.md](IMAGE_GUIDE.md)** - How to add your images
- **[CONTACT_SETUP_GUIDE.md](CONTACT_SETUP_GUIDE.md)** - How to set up contact functionality
- **[Attributions.md](Attributions.md)** - Credits and licenses

---

## 🎉 You're All Set!

Once you've completed all the steps above:

1. ✅ Test everything thoroughly
2. ✅ Push to GitHub
3. ✅ Deploy to your hosting platform
4. ✅ Share your portfolio with the world!

Good luck with your portfolio! 🚀

---

## 💡 Tips for Success

1. **Keep it updated:** Regularly update your portfolio with new projects and skills
2. **Use real photos:** Professional photos make a huge difference
3. **Write clearly:** Use simple, clear language to describe your work
4. **Test on devices:** View on different screen sizes before deploying
5. **Get feedback:** Ask friends to review before sharing widely
6. **Monitor analytics:** Use Google Analytics to see who visits
7. **SEO matters:** Add proper meta tags for better search visibility

---

**Need help?** Check the individual guide files or review the component code comments for more details.
