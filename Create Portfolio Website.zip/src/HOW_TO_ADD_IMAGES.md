# How to Add Your Own Images - Simple Guide

## ⚠️ Critical Information

**You CANNOT import local .jpg/.png files in Figma Make!**

This will **NOT** work:
```tsx
❌ import myImage from './photo.jpg'
❌ import myImage from '/public/photo.jpg'
❌ const image = "/photo.jpg"
```

You **MUST** use external image hosting services.

---

## ✅ The ONLY Way to Add Images

### Step-by-Step Process

#### 1️⃣ Prepare Your Image

**About Section:**
- Dimensions: 1200px × 1400px (portrait/vertical)
- File size: Under 500KB
- Format: JPG or PNG

**Leadership Section:**
- Dimensions: 1920px × 1080px (landscape/horizontal) 
- File size: Under 300KB
- Format: JPG or PNG

**Tools to resize:**
- [ILoveIMG](https://www.iloveimg.com/resize-image) - Online resizer
- [TinyPNG](https://tinypng.com/) - Compress images

---

#### 2️⃣ Upload to Image Hosting

**🏆 RECOMMENDED: ImgBB (Easiest & Most Reliable)**

1. Go to **[https://imgbb.com/](https://imgbb.com/)**
2. Click "Start uploading" (no account needed!)
3. Upload your image
4. Copy the **"Direct link"** - it's shown immediately!
5. You'll get: `https://i.ibb.co/abc123/yourimage.jpg`

**Why ImgBB?** It gives you the direct link immediately with no confusion!

**Alternative: Postimages**

1. Go to **[https://postimages.org/](https://postimages.org/)**
2. Click "Choose images"
3. Upload and copy the "Direct link"

**Alternative: Imgur** (More complicated)

1. Go to **[https://imgur.com/upload](https://imgur.com/upload)**
2. Upload your image
3. **Click on the image** to view it full-size
4. **Right-click on the image** → "Copy Image Address"
5. You'll get: `https://i.imgur.com/abc123.jpg`

⚠️ **Note:** Imgur creates albums, so the album URL is different from the image URL!

📖 **See [RELIABLE_IMAGE_HOSTING.md](./RELIABLE_IMAGE_HOSTING.md) for detailed comparison**

---

#### 3️⃣ Add URL to Your Code

**For About Section:**

1. Open `/components/AnimatedAbout.tsx`
2. Find line ~16 that says:
   ```tsx
   const aboutImage = "https://images.unsplash.com/photo-...";
   ```
3. Replace with your Imgur URL:
   ```tsx
   const aboutImage = "https://i.imgur.com/YOUR-ID.jpg";
   ```

**For Leadership Section:**

1. Open `/components/ExpandableExtracurriculars.tsx`
2. Find the `activities` array (around line 15)
3. Find the activity you want to update
4. Replace the `image:` URL:
   ```tsx
   {
     title: "Computer Science Club",
     role: "Vice President",
     // ... other fields ...
     image: "https://i.imgur.com/YOUR-ID.jpg"  // ← Replace this line
   }
   ```

**For Certificates:**

1. Open `/components/SimpleCertificates.tsx`
2. Find the `certificates` array (around line 9)
3. Update both `image` (preview) and `certificateImage` (full view):
   ```tsx
   {
     id: 1,
     title: "Your Certification",
     image: "https://i.imgur.com/PREVIEW-ID.jpg",           // Preview
     certificateImage: "https://i.imgur.com/FULL-ID.jpg",   // Full certificate
     // ... other fields
   }
   ```

---

## 🎯 Complete Example

Let's say you want to add a photo of yourself to the About section:

### Step 1: Prepare
- Take/find your photo
- Go to [ILoveIMG Resize](https://www.iloveimg.com/resize-image)
- Resize to 1200 × 1400 pixels
- Download the resized image as `my-photo.jpg`

### Step 2: Upload
- Go to [imgur.com/upload](https://imgur.com/upload)
- Drag `my-photo.jpg` to upload
- Right-click the uploaded image → "Copy image address"
- You get: `https://i.imgur.com/k7Xm9pQ.jpg`

### Step 3: Add to Code
Open `/components/AnimatedAbout.tsx` and change line 16:

**Before:**
```tsx
const aboutImage = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=1400&fit=crop";
```

**After:**
```tsx
const aboutImage = "https://i.imgur.com/k7Xm9pQ.jpg";
```

Save the file and your photo will appear! ✨

---

## 🔍 Finding the Right Line to Edit

### AnimatedAbout.tsx
```tsx
// Around line 10-16
const subtitle1Text = "Passionate about...";
const subtitle2Text = "With expertise...";
// ... more text ...

const aboutImage = "URL_HERE";  // ← Change this line
```

### ExpandableExtracurriculars.tsx
```tsx
// Around line 15-88
const activities = [
  {
    title: "Computer Science Club",
    role: "Vice President",
    description: "Leading a team...",
    fullDescription: "As Vice President...",
    period: "2023 - Present",
    icon: Users,
    metrics: [...],
    achievements: [...],
    image: "URL_HERE"  // ← Change this line
  },
  {
    title: "Debate Society",
    // ...
    image: "URL_HERE"  // ← And this one
  },
  // ... more activities
];
```

### SimpleCertificates.tsx
```tsx
// Around line 9-40
const certificates = [
  {
    id: 1,
    title: "AWS Certified Developer",
    issuer: "Amazon Web Services",
    date: "March 2024",
    image: "URL_HERE",           // ← Preview thumbnail
    certificateImage: "URL_HERE", // ← Full certificate
    description: "Professional certification..."
  },
  // ... more certificates
];
```

---

## ❓ Troubleshooting

### "My image doesn't show up"
- ✅ Make sure you copied the **direct image link** (should end in `.jpg`, `.png`, or `.gif`)
- ✅ Try opening the URL in a new browser tab - you should see ONLY the image
- ✅ Check for typos in the URL

### "Image looks blurry"
- Upload a higher resolution image
- For About: Use at least 1200×1400
- For Leadership: Use at least 1920×1080

### "Wrong aspect ratio"
- About section needs **portrait** (vertical) - 1200×1400
- Leadership needs **landscape** (horizontal) - 1920×1080
- Use [ILoveIMG Resize](https://www.iloveimg.com/resize-image) to fix

### "File is too large"
- Compress using [TinyPNG](https://tinypng.com/)
- Or reduce quality when saving as JPG (80-85% quality is fine)

---

## 📝 Quick Reference

| Section | File | Line # | Dimensions | Format |
|---------|------|--------|------------|--------|
| About | `/components/AnimatedAbout.tsx` | ~16 | 1200×1400 | Portrait |
| Leadership | `/components/ExpandableExtracurriculars.tsx` | ~35, 52, 69, 86 | 1920×1080 | Landscape |
| Certificates (preview) | `/components/SimpleCertificates.tsx` | ~14, 24, etc | 800×600 | Landscape |
| Certificates (full) | `/components/SimpleCertificates.tsx` | ~15, 25, etc | Original size | Portrait |

---

## 💡 Pro Tips

1. **Keep URLs organized**: Save your Imgur links in a text file for reference
2. **Use descriptive names**: When uploading to Imgur, name files like `cs-club-event.jpg`
3. **Batch upload**: Upload all your images to Imgur at once
4. **Test immediately**: After updating the URL, check if the image displays correctly
5. **Use consistent style**: Try to keep similar lighting/color tone across all images

---

Need more help? Check the detailed guides:
- [LEADERSHIP_IMAGE_GUIDE.md](./LEADERSHIP_IMAGE_GUIDE.md) - Detailed leadership image guide
- [IMAGE_GUIDE.md](./IMAGE_GUIDE.md) - Complete image guide for all sections
