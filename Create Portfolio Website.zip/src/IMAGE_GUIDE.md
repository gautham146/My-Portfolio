# Guide: How to Add Your Own Images

This guide explains how to add your own images throughout the portfolio.

## ⚠️ Important: Image Hosting Required

**In Figma Make, you CANNOT use local image files.** You must upload images to an external hosting service and use the URL.

## Quick Start

### Using External Image Hosting (REQUIRED)

1. **Upload your image** to a free hosting service:
   - **Imgur** (Recommended): [imgur.com/upload](https://imgur.com/upload)
   - **ImgBB**: [imgbb.com](https://imgbb.com/)
   - **Postimages**: [postimages.org](https://postimages.org/)

2. **Get the direct image URL** (right-click → "Copy image address")

3. **Paste the URL** into your code where the placeholder URL is

### Example:
```tsx
// ❌ DOES NOT WORK in Figma Make
import myPhoto from './images/photo.jpg';
const aboutImage = "/my-photo.jpg";

// ✅ WORKS - Use external URL
const aboutImage = "https://i.imgur.com/abc123.jpg";
```

## Where to Add Images

### 1. About Section (`/components/AnimatedAbout.tsx`)

**Current placeholder:**
```tsx
const aboutImage = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=1400&fit=crop";
```

**To replace with your own image:**

1. Upload your photo to [Imgur](https://imgur.com/upload)
2. Right-click the uploaded image → "Copy image address"
3. Replace the URL:

```tsx
// Replace this line (around line 16):
const aboutImage = "https://i.imgur.com/YOUR-IMAGE-ID.jpg";  // ← Paste your Imgur URL
```

**Recommended dimensions:** 1200x1400px (portrait orientation)

---

### 2. Leadership & Impact Section (`/components/ExpandableExtracurriculars.tsx`)

Each activity card has an image. Look for the comments that say `// REPLACE WITH YOUR LOCAL IMAGE`

**Current placeholders:**
- Computer Science Club
- Debate Society  
- Community Service Initiative
- University Tech Magazine

**To replace:**

1. Upload your images to [Imgur](https://imgur.com/upload)
2. Get the direct image URLs
3. Update the `image` field in each activity:

```tsx
{
  title: "Computer Science Club",
  // ... other fields
  image: "https://i.imgur.com/YOUR-IMAGE-ID.jpg"  // ← Your Imgur URL
}
```

**Recommended dimensions:** 1920x1080px (landscape/horizontal orientation) - these images work best in a 16:9 ratio for the expanded modal view.

📖 **For detailed image preparation instructions, see:** [`LEADERSHIP_IMAGE_GUIDE.md`](./LEADERSHIP_IMAGE_GUIDE.md)

---

### 3. Hero Section (`/components/MinimalistHero.tsx`)

Currently has no image placeholder, but if you want to add a background image:

```tsx
<div 
  className="min-h-screen flex items-center justify-center relative pt-24"
  style={{ backgroundImage: 'url(/hero-background.jpg)', backgroundSize: 'cover' }}
>
```

---

### 4. Certificates Section (`/components/SimpleCertificates.tsx`)

**Two images per certificate:**
1. **Preview thumbnail** - Shows in the grid (4:3 aspect ratio recommended)
2. **Full certificate image** - Opens when clicked (portrait/vertical orientation)

**File:** `/components/SimpleCertificates.tsx`

Find the `certificates` array (around line 9) and update:

```tsx
const certificates = [
  {
    id: 1,
    title: "Your Certification Name",
    issuer: "Issuing Organization",
    date: "January 2025",
    image: "/cert-preview-1.jpg",           // Preview thumbnail (shows in grid)
    certificateImage: "/certificate-1.jpg", // Full certificate (opens on click)
    description: "Brief description of this certification"
  },
  {
    id: 2,
    title: "Another Certification",
    issuer: "Organization Name",
    date: "December 2024",
    image: "/cert-preview-2.jpg",
    certificateImage: "/certificate-2.jpg",
    description: "Brief description of this certification"
  }
];
```

**Image specifications:**
- **Preview thumbnail** (`image`): 4:3 ratio, around 800x600px
- **Full certificate** (`certificateImage`): Portrait orientation (e.g., 2480x3508px for A4), this is the actual certificate scan/image that opens when you click

**To add your certificates:**
1. Place certificate images in `/public` folder (e.g., `/public/my-certificate.jpg`)
2. Update the `certificateImage` path to `"/my-certificate.jpg"`
3. Optionally create a smaller preview thumbnail for the `image` field

The certificate viewer will open in a modal with the portrait certificate displayed at an appropriate size (max 90% of screen height).

---

### 5. Medium Blogs (`/components/MediumBlogs.tsx`)

**Medium Blogs (`/components/MediumBlogs.tsx`):**
- No images needed - just update the blog links, titles, and excerpts
- See the Medium Blogs Setup section below for details

---

## Image Optimization Tips

1. **File Size:** Keep images under 500KB when possible for faster loading (certificates can be larger for quality)
2. **Format:** Use JPG for photos, PNG for graphics with transparency, PDF can be converted to JPG
3. **Dimensions:** 
   - About section: 1200x1400px (portrait)
   - Leadership cards: 1920x1080px (landscape)
   - Certificate previews: 800x600px (4:3 ratio)
   - Full certificates: Original certificate size (portrait, typically A4: 2480x3508px)
4. **Naming:** Use descriptive names without spaces (e.g., `cs-club-event.jpg` not `CS Club Event.jpg`)

## Example: Complete Replacement for About Section

```tsx
// /components/AnimatedAbout.tsx

import React from 'react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Import your image
import myProfilePhoto from '../assets/images/profile.jpg';

const AnimatedAbout = () => {
  // ... other code ...
  
  const aboutImage = myProfilePhoto;  // Use imported image
  
  // Or use public folder:
  // const aboutImage = "/profile.jpg";
  
  // ... rest of component ...
}
```

## Medium Blogs Setup

The Medium Blogs section doesn't need images, but you should update the blog information.

**File:** `/components/MediumBlogs.tsx`

Update each blog object in the `blogs` array:

```tsx
const blogs = [
  {
    title: "Your Blog Title",
    excerpt: "A brief description of your blog post...",
    date: "Jan 15, 2025",
    readTime: "5 min read",
    views: "2.4K",
    link: "https://medium.com/@yourusername/your-article-slug"
  },
  {
    title: "Your Second Blog Title",
    excerpt: "Another brief description...",
    date: "Dec 28, 2024",
    readTime: "8 min read",
    views: "1.8K",
    link: "https://medium.com/@yourusername/your-second-article"
  }
];
```

**Note:** The portfolio is set to show only 2 blog posts for a cleaner look.

---

## Need Help?

If you're having trouble with images:
1. Check that the file path is correct
2. Ensure the image file exists in the specified location
3. Verify the image format is supported (JPG, PNG, WebP, SVG)
4. Check browser console for any error messages

**For contact page setup:** See `CONTACT_SETUP_GUIDE.md` for detailed instructions on setting up your contact information and email functionality.
