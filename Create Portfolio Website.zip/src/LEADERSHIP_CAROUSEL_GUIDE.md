# Leadership Image Carousel Guide

Your Leadership & Impact section now features **revolving image carousels** inside the expanded modal view! When you click on any leadership card, the full-screen modal displays multiple images that automatically rotate every 4 seconds.

---

## 🎯 How It Works

**Preview Cards:**
- Show a single static image with reduced height (h-48 = 192px)
- Clean, compact design
- Click to expand and see the full carousel

**Expanded Modal:**
- Displays **all images** in an auto-rotating carousel
- ✨ Smooth crossfade transitions (1 second)
- 🔄 Auto-rotation every 4 seconds
- ◀️ ▶️ Manual navigation arrows
- 📍 Clickable indicator dots
- 🔢 Image counter (e.g., "2 / 5")
- 🎨 Professional carousel design

---

## ✅ Current Setup

**All 4 leadership activities now have 3 sample images each:**

1. **Computer Science Club** - 3 coding/hackathon images
2. **Debate Society** - 3 public speaking images  
3. **Community Service Initiative** - 3 teaching/volunteer images
4. **University Tech Magazine** - 3 writing/journalism images

Click on any card to see the carousel in action! The images will auto-rotate every 4 seconds.

---

## 📝 How to Add More Images

### Step 1: Find the Activity in the Code

Open `/components/ExpandableExtracurriculars.tsx` and locate your activity. Each activity has an `images` array:

```tsx
{
  title: "Computer Science Club",
  role: "Vice President",
  description: "...",
  // ... other properties ...
  images: [
    "https://i.ibb.co/image1.jpg",  // First image (shown on preview card)
    "https://i.ibb.co/image2.jpg",  // Second image (in modal carousel)
    "https://i.ibb.co/image3.jpg"   // Third image (in modal carousel)
  ]
}
```

**Note:** The first image in the array is displayed on the preview card. All images appear in the carousel when you click the card.

### Step 2: Upload Your Images

1. Go to **[imgbb.com](https://imgbb.com/)**
2. Click "Start uploading"
3. Upload your image(s)
4. Copy each "Direct link"

**Recommended image sizes:**
- **Dimensions:** 1920 × 1440 pixels (4:3 ratio)
- **File size:** Under 500KB (compress at [tinypng.com](https://tinypng.com/))

### Step 3: Add URLs to the Array

Simply add more URLs to the `images` array, separated by commas:

```tsx
images: [
  "https://i.ibb.co/image1.jpg",
  "https://i.ibb.co/image2.jpg",
  "https://i.ibb.co/image3.jpg",  // Added third image
  "https://i.ibb.co/image4.jpg"   // Added fourth image
]
```

**That's it!** The carousel will automatically rotate through all images.

---

## 📋 Complete Examples

### Example 1: Single Image (No Carousel)

```tsx
{
  title: "Debate Society",
  role: "Active Member",
  // ... other properties ...
  images: [
    "https://i.ibb.co/abc123/debate.jpg"
  ]
}
```

**Result:** 
- Preview card shows the single image
- Modal shows the same image (no carousel controls, since there's only 1 image)

---

### Example 2: Two Images (Basic Carousel)

```tsx
{
  title: "Computer Science Club",
  role: "Vice President",
  // ... other properties ...
  images: [
    "https://i.ibb.co/abc123/hackathon.jpg",
    "https://i.ibb.co/def456/workshop.jpg"
  ]
}
```

**Result:** 
- Preview card shows first image (hackathon.jpg)
- Click to expand: Modal carousel rotates between both images
- Shows navigation arrows, 2 indicator dots, and counter "1 / 2" or "2 / 2"

---

### Example 3: Multiple Images (Full Carousel Experience)

```tsx
{
  title: "Community Service Initiative",
  role: "Volunteer Coordinator",
  // ... other properties ...
  images: [
    "https://i.ibb.co/abc123/teaching1.jpg",
    "https://i.ibb.co/def456/teaching2.jpg",
    "https://i.ibb.co/ghi789/lab-setup.jpg",
    "https://i.ibb.co/jkl012/graduation.jpg",
    "https://i.ibb.co/mno345/team-photo.jpg"
  ]
}
```

**Result:** 
- Preview card shows first image (teaching1.jpg)
- Click to expand: Full modal carousel with all 5 images
- Auto-rotates through all images every 4 seconds
- Navigation arrows to manually browse
- 5 clickable indicator dots
- Counter shows "1 / 5", "2 / 5", etc.

---

## 🎨 Image Selection Tips

### What Images to Use

**For Computer Science Club:**
- Hackathon events
- Coding workshops
- Team meetings
- Guest speaker sessions
- Project showcases

**For Debate Society:**
- Competition moments
- Practice sessions
- Award ceremonies
- Team photos
- Public speaking events

**For Community Service:**
- Teaching sessions
- Student interactions
- Lab setups
- Graduation ceremonies
- Team volunteer photos

**For Tech Magazine:**
- Writing/editing sessions
- Published articles
- Interview moments
- Team meetings
- Event coverage

### Image Quality Guidelines

✅ **DO:**
- Use high-quality, clear images
- Keep consistent lighting/style across images
- Show different aspects of the activity
- Include people/action shots
- Use horizontal (landscape) orientation

❌ **DON'T:**
- Use blurry or low-quality images
- Mix drastically different styles
- Include irrelevant images
- Use vertical (portrait) images (they'll be cropped)
- Add too many images (3-5 is ideal)

---

## 🔧 Customization Options

### Change Rotation Speed

**Current:** Images change every 4 seconds

**To change:**

1. Open `/components/ExpandableExtracurriculars.tsx`
2. Find this line (around line 135):
   ```tsx
   }, 4000); // Change image every 4 seconds
   ```
3. Change `4000` to your preferred milliseconds:
   - `3000` = 3 seconds
   - `5000` = 5 seconds
   - `6000` = 6 seconds

### Change Transition Duration

**Current:** 1 second smooth crossfade

**To change:**

1. Find this line (around line 215):
   ```tsx
   className="absolute inset-0 transition-opacity duration-1000"
   ```
2. Change `duration-1000` to your preference:
   - `duration-500` = 0.5 seconds (faster)
   - `duration-1500` = 1.5 seconds (slower)
   - `duration-2000` = 2 seconds (very slow)

### Disable Carousel Indicators

If you don't want the dots at the bottom:

1. Find this section (around line 228):
   ```tsx
   {/* Carousel indicators */}
   {activity.images.length > 1 && (
     <div className="absolute bottom-4...">
       {/* ... indicator dots ... */}
     </div>
   )}
   ```
2. Delete or comment out the entire section

---

## 📍 Where to Find Each Activity

In `/components/ExpandableExtracurriculars.tsx`:

| Activity | Approximate Line | Current Images |
|----------|------------------|----------------|
| Computer Science Club | Line 30-45 | 2 images |
| Debate Society | Line 47-62 | 1 image |
| Community Service | Line 64-79 | 1 image |
| Tech Magazine | Line 81-96 | 1 image |

---

## 🚀 Quick Start Checklist

Adding images to **Computer Science Club** as an example:

- [ ] Open `/components/ExpandableExtracurriculars.tsx`
- [ ] Find the Computer Science Club activity (around line 30)
- [ ] Upload 3-5 images to [imgbb.com](https://imgbb.com/)
- [ ] Copy each "Direct link"
- [ ] Paste URLs into the `images` array:
  ```tsx
  images: [
    "https://i.ibb.co/abc123/image1.jpg",
    "https://i.ibb.co/def456/image2.jpg",
    "https://i.ibb.co/ghi789/image3.jpg"
  ]
  ```
- [ ] Save the file
- [ ] Check your portfolio - images should auto-rotate!

---

## 💡 Pro Tips

### 1. **Tell a Story**
Arrange images in chronological order to show progression:
```tsx
images: [
  "first-event.jpg",      // Beginning
  "growth-phase.jpg",     // Development
  "major-achievement.jpg" // Success
]
```

### 2. **Maintain Visual Consistency**
Use similar:
- Color tones
- Lighting conditions
- Image composition
- Photo quality

### 3. **Optimize Before Uploading**
- Resize to 1920×1440 pixels
- Compress at [tinypng.com](https://tinypng.com/)
- Target under 500KB per image

### 4. **Ideal Number of Images**
- **1 image:** No carousel (static)
- **2-3 images:** Perfect for simple rotation
- **4-5 images:** Ideal for full story
- **6+ images:** Can be overwhelming (not recommended)

### 5. **Test Your URLs**
Before adding to code:
1. Copy the ImgBB URL
2. Paste in a new browser tab
3. Should see ONLY the image
4. If yes → ✅ Ready to use!

---

## 🛠️ Troubleshooting

### "Images not rotating"

**This is normal for preview cards!** Images only rotate in the **expanded modal view**.

**To test:**
1. Click on a leadership card to open the modal
2. The carousel should auto-rotate every 4 seconds
3. You should see navigation arrows and indicators (if you have 2+ images)

**If still not rotating in the modal:**
1. Do you have more than 1 image in the array?
   - Single images don't rotate (by design)
2. Are the URLs correct?
   - Test each URL in a browser tab
3. Is there a syntax error?
   - Each URL should be in quotes
   - URLs separated by commas
   - Last URL has NO comma after it

**Example of CORRECT syntax:**
```tsx
images: [
  "url1.jpg",  // ✅ Comma after
  "url2.jpg",  // ✅ Comma after
  "url3.jpg"   // ✅ NO comma (last one)
]
```

**Example of WRONG syntax:**
```tsx
images: [
  "url1.jpg"   // ❌ Missing comma
  "url2.jpg",  // ❌ Will cause error
  "url3.jpg",  // ❌ Extra comma (will work but not ideal)
]
```

### "Carousel indicators not showing"

**This is normal if:**
- You're looking at the preview card (carousel is only in the modal)
- You only have 1 image (indicators only show for 2+ images)

**Check:**
1. Click the card to open the modal view
2. Count your images in the array
3. Indicators, arrows, and counter only appear in the modal when you have 2+ images

### "Images look stretched or cropped"

**Solution:**
- Use **4:3 aspect ratio** images (horizontal/landscape)
- Recommended: 1920×1440 pixels
- The card uses `aspect-[4/3]` so images are displayed at 4:3 ratio
- Portrait (vertical) images will be cropped to fit

### "Image not showing at all"

**Check:**
1. **URL format:**
   - Should start with `https://i.ibb.co/`
   - Should end with `.jpg`, `.png`, or `.gif`
   
2. **Test the URL:**
   - Paste in browser
   - Should see ONLY the image (no website)

3. **Quotes and commas:**
   ```tsx
   images: [
     "https://i.ibb.co/abc123.jpg"  // ✅ Correct
   ]
   
   // NOT:
   images: [
     https://i.ibb.co/abc123.jpg    // ❌ Missing quotes
   ]
   ```

---

## 📊 How It Works Now

### Preview Card (Compact View)
- **Height:** Reduced to `h-48` (192px) - more compact!
- **Image:** Shows only the first image from the array
- **Behavior:** Static (no rotation)
- **Purpose:** Clean preview to browse your activities

### Expanded Modal (Full Experience)
- **Height:** Large `h-[500px]` image area
- **Images:** All images in the array
- **Auto-rotation:** Every 4 seconds with smooth crossfade
- **Manual controls:** 
  - ◀️ Previous / Next ▶️ arrow buttons
  - Clickable indicator dots
  - Image counter display
- **Purpose:** Full immersive showcase of each activity

### Current Structure
```tsx
{
  title: "Computer Science Club",
  // ...
  images: [
    "image1.jpg",  // ← Shows on preview card + first in carousel
    "image2.jpg",  // ← Only in modal carousel
    "image3.jpg"   // ← Only in modal carousel
  ]
}
```

---

## 🎓 Advanced Features Already Included!

Your carousel already has **full manual controls**:

### Navigation Arrows
- **Previous (◀):** Click to go to the previous image
- **Next (▶):** Click to go to the next image
- Loops seamlessly (last image → first image, and vice versa)

### Clickable Indicators
- Click any dot to jump directly to that image
- Active dot is highlighted and wider
- Smooth transitions between images

### Image Counter
- Shows current position (e.g., "3 / 5")
- Located in top-right corner
- Semi-transparent black background

### Auto-Rotation
- Automatically advances every 4 seconds
- Pauses when you manually navigate (then resumes)
- Smooth 1-second crossfade transitions

**All of this works out of the box! Just add your images.**

---

## 📞 Need Help?

If you're stuck:

1. ✅ Check the [RELIABLE_IMAGE_HOSTING.md](./RELIABLE_IMAGE_HOSTING.md) guide
2. ✅ Verify your image URLs work in a browser
3. ✅ Check for syntax errors (quotes, commas)
4. ✅ Make sure you're editing the right activity

**Common Mistakes:**
- Forgetting quotes around URLs
- Missing commas between URLs
- Extra comma after last URL (won't break but not clean)
- Using album URLs instead of direct image URLs
- Using portrait images (use landscape!)

---

## 🎉 You're All Set!

Your leadership cards now have professional rotating image carousels! Add more images to tell richer stories about your leadership experiences.

**Remember:**
- Upload to [imgbb.com](https://imgbb.com/)
- Copy "Direct link"
- Add to `images` array
- Save and enjoy!

Happy showcasing! 🚀
