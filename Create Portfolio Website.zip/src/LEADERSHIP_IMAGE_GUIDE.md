# Leadership Section Image Guide

This guide will help you prepare and add images for the Leadership & Impact section so they display beautifully in the expanded view.

## ⚠️ Important: How Images Work in This Environment

**In Figma Make, you CANNOT import local .jpg/.png files directly.** Instead, you must use one of these methods:

1. **External Image URLs** (Recommended) - Upload to Imgur, ImgBB, or use Unsplash
2. **Base64 Data URLs** (Not recommended for large images)

## 📐 Recommended Image Dimensions

For the best display in the leadership expanded boxes, we recommend:

### **Ideal Dimensions**
- **Aspect Ratio**: 16:9 (horizontal/landscape)
- **Width**: 1920px
- **Height**: 1080px
- **Or any equivalent**: 1600x900, 1280x720, etc.

### **Why These Dimensions?**

The expanded leadership boxes display images in a **500px tall container** with padding. Using a 16:9 landscape image ensures:
- ✅ The full image displays without cropping
- ✅ No blurriness or distortion
- ✅ Professional, cinematic appearance
- ✅ Balanced proportions with the text content below

## 🖼️ Image Preparation Steps

### Step 1: Choose Your Image
Select a high-quality horizontal image that represents the activity. Good choices include:
- Group photos from events
- Action shots during activities
- Event banners or promotional materials
- Wide-angle photos of the activity in progress

### Step 2: Resize Your Image

**Using Online Tools (Easy)**:
1. Go to [https://www.iloveimg.com/resize-image](https://www.iloveimg.com/resize-image)
2. Upload your image
3. Select "By pixels"
4. Enter Width: 1920, Height: 1080
5. Download the resized image

**Using Photoshop/GIMP**:
1. Open your image
2. Image → Image Size
3. Set Width: 1920px, Height: 1080px
4. Make sure "Constrain Proportions" is checked
5. If your image doesn't match 16:9, crop it first using the crop tool
6. Export as JPG (quality: 85-90%)

**Using Figma**:
1. Create a 1920x1080 frame
2. Place your image inside
3. Scale to fill the frame (maintaining aspect ratio)
4. Export as JPG or PNG

### Step 3: Optimize File Size

Keep your images under 300KB for fast loading:
- Use [TinyPNG](https://tinypng.com/) or [Squoosh](https://squoosh.app/)
- Compress without losing visible quality
- JPG format is recommended for photos

## 📁 How to Add Your Images

### Method 1: Upload to Free Image Hosting (Recommended & Easiest)

This is the **ONLY way** to use your own images in Figma Make.

#### Step-by-Step:

1. **Prepare your image** (see Image Preparation Steps below)

2. **Upload to a free image hosting service**:
   
   **Option A: Imgur (Recommended)**
   - Go to [https://imgur.com/upload](https://imgur.com/upload)
   - Click "New post" or drag your image
   - Upload your image (no account needed!)
   - Right-click the uploaded image → "Copy image address"
   - You'll get a URL like: `https://i.imgur.com/XXXXX.jpg`
   
   **Option B: ImgBB**
   - Go to [https://imgbb.com/](https://imgbb.com/)
   - Click "Start uploading"
   - Upload your image
   - Copy the "Direct link" URL
   
   **Option C: Postimages**
   - Go to [https://postimages.org/](https://postimages.org/)
   - Upload your image
   - Copy the direct link

3. **Add the URL to your code**:

   Open `/components/ExpandableExtracurriculars.tsx` and find the activities array (around line 15).
   
   Replace the image URL:
   ```tsx
   const activities = [
     {
       title: "Computer Science Club",
       role: "Vice President",
       description: "Leading a team of 50+ students...",
       // ... other properties ...
       image: "https://i.imgur.com/YOUR-IMAGE-ID.jpg"  // ← Paste your URL here
     },
     // ... more activities
   ];
   ```

### Method 2: Use Unsplash (For Stock/Placeholder Images)

If you want to use high-quality stock photos:

1. Go to [https://unsplash.com/](https://unsplash.com/)
2. Search for relevant images (e.g., "coding students", "debate competition")
3. Click on an image
4. Click "Download" → Right-click → "Copy image address"
5. Use that URL in your code

### ❌ What DOESN'T Work

These methods will **NOT** work in Figma Make:
```tsx
// ❌ DOES NOT WORK - Cannot import local files
import myImage from './images/photo.jpg';
import myImage from '/public/photo.jpg';
import myImage from '../assets/photo.jpg';

// ❌ DOES NOT WORK - No public folder served
image: "/photo.jpg"
image: "/public/photo.jpg"

// ✅ WORKS - External URL
image: "https://i.imgur.com/abc123.jpg"
```

## ✅ Image Checklist

Before adding your image, ensure:

- [ ] Image is **horizontal/landscape** orientation
- [ ] Dimensions are close to **16:9 ratio** (1920x1080 recommended)
- [ ] File size is **under 300KB**
- [ ] Image is **high quality** (not blurry or pixelated)
- [ ] File format is **JPG or PNG**
- [ ] Image is **relevant** to the activity described
- [ ] Colors and lighting are **professional**

## 🎨 Image Style Tips

For a cohesive portfolio look:

1. **Color Consistency**: Try to maintain similar color tones across all leadership images
2. **Lighting**: Use well-lit, clear images
3. **Composition**: Avoid cluttered backgrounds
4. **Quality**: Always use the highest quality available
5. **Professionalism**: Choose images that reflect your leadership role

## ⚠️ Common Issues & Solutions

### Issue: Image looks blurry
**Solution**: Use a higher resolution source image (at least 1920x1080)

### Issue: Image doesn't fill the space properly
**Solution**: Make sure your image is horizontal (landscape) with a 16:9 aspect ratio

### Issue: Image has wrong colors
**Solution**: Ensure your image is in RGB color mode (not CMYK)

### Issue: File is too large
**Solution**: Compress using TinyPNG or reduce JPG quality to 85%

### Issue: Image shows black bars on sides
**Solution**: Your image may be taller than 16:9. Re-crop to 16:9 aspect ratio

## 📱 Responsive Behavior

The leadership images automatically adapt to:
- **Desktop**: Full 500px height display
- **Tablet**: Proportionally scaled
- **Mobile**: Automatically adjusted to screen width

The `object-contain` property ensures your entire image is always visible without cropping.

## 🔄 Complete Example

Here's a complete example of adding a custom image:

### Step 1: Prepare Your Image
- Resize to 1920x1080 (16:9 ratio)
- Compress to under 300KB using [TinyPNG](https://tinypng.com/)
- Save as `cs-club-event.jpg`

### Step 2: Upload to Imgur
- Go to [imgur.com/upload](https://imgur.com/upload)
- Upload `cs-club-event.jpg`
- Right-click → Copy image address
- Get URL: `https://i.imgur.com/abc123.jpg`

### Step 3: Update Your Code

Open `/components/ExpandableExtracurriculars.tsx` and modify:

```tsx
const activities = [
  {
    title: "Computer Science Club",
    role: "Vice President",
    description: "Leading a team of 50+ students in organizing coding competitions, workshops, and tech talks.",
    fullDescription: "As Vice President of the Computer Science Club...",
    period: "2023 - Present",
    icon: Users,
    metrics: ["50+ Members", "15+ Colleges", "12 Events"],
    achievements: [
      "Increased membership by 300% in one year",
      "Organized the largest campus hackathon with 200+ participants", 
      // ... more achievements
    ],
    image: "https://i.imgur.com/abc123.jpg"  // ← Your Imgur URL here
  },
  // ... other activities
];
```

### Step 4: Save and View
Your image will now display in the leadership section!

## 💡 Pro Tips

- **Batch Resize**: If you have multiple images, use [Bulk Resize Photos](https://bulkresizephotos.com/) to resize them all at once
- **Consistency**: Use images from the same event or similar lighting conditions
- **Backup**: Always keep original high-resolution versions of your images
- **Testing**: After adding images, test on different screen sizes to ensure they look good

---

Need help? Check the comments in `/components/ExpandableExtracurriculars.tsx` for inline guidance!
